import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import '../styles/OrderStatus.css';

function OrderStatus() {
  const { state } = useLocation();
  const [customerName, setCustomerName] = useState('');
  const [customerOrders, setCustomerOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Automatically load customer name from state or localStorage
  useEffect(() => {
    const nameFromState = state?.customerName;
    const nameFromStorage = localStorage.getItem('currentCustomerName');

    if (nameFromState) {
      setCustomerName(nameFromState);
      localStorage.setItem('currentCustomerName', nameFromState);
    } else if (nameFromStorage) {
      setCustomerName(nameFromStorage);
    } else {
      setErrorMsg("Customer name not found. Please log in again.");
    }
  }, [state]);

  // Fetch orders when customerName is available
  useEffect(() => {
    if (!customerName) return;

    const fetchOrders = async () => {
      setLoading(true);
      setErrorMsg('');

      try {
        const res = await axios.get(`http://localhost:8080/orders/my-orders/${customerName}`);
        setCustomerOrders(res.data);
      } catch (err) {
        console.error("Failed to fetch orders:", err);
        setErrorMsg("❌ Could not fetch orders. Try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [customerName]);

  return (
    <div className="order-status-container">
      <h2>📦 Your Order Status</h2>

      {customerName && (
        <p className="customer-name-display"><strong>Customer:</strong> {customerName}</p>
      )}

      {errorMsg && <p className="error-message">{errorMsg}</p>}
      {loading ? (
        <p>Loading orders...</p>
      ) : (
        <div className="order-results">
          {customerOrders.length > 0 ? (
            customerOrders.map(order => (
              <div key={order.orderId} className="order-card">
                <p><strong>Order ID:</strong> {order.orderId}</p>
                <p><strong>Product:</strong> {order.productName}</p>
                <p><strong>Quantity:</strong> {order.quantity}</p>
                <p><strong>Address:</strong> {order.address}</p>
                <p><strong>Status:</strong> {order.status}</p>
                {order.rejectionReason && (
                  <p><strong>Rejection Reason:</strong> {order.rejectionReason}</p>
                )}
                {order.notification && (
                  <p><strong>Notification:</strong> {order.notification}</p>
                )}
              </div>
            ))
          ) : (
            <p>No orders found for this customer.</p>
          )}
        </div>
      )}
    </div>
  );
}

export default OrderStatus;
