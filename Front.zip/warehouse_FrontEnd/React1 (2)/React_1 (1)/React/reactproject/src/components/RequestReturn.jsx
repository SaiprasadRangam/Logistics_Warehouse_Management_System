import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

export default function RequestReturn() {
  const { state } = useLocation();
  const username = state?.username || '';
  const firstName = state?.firstName || '';
  const lastName = state?.lastName || '';
  const fullName = `${firstName} ${lastName}`.trim();

  const [orders, setOrders] = useState([]);
  const [selectedOrders, setSelectedOrders] = useState({});
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (username) {
      axios.get(`http://localhost:8080/orders/my-orders/${username}`)
        .then(res => setOrders(res.data))
        .catch(err => {
          console.error("Error fetching customer orders:", err);
          setMessage("Failed to load orders.");
        });
    }
  }, [username]);

  const toggleSelection = (orderId) => {
    setSelectedOrders(prev => ({
      ...prev,
      [orderId]: !prev[orderId]
    }));
  };

  const handleSubmit = async () => {
    const selectedIds = Object.keys(selectedOrders).filter(id => selectedOrders[id]);
    if (selectedIds.length === 0) {
      setMessage("Please select at least one item to return.");
      return;
    }

    try {
      for (const id of selectedIds) {
        await axios.post(`http://localhost:8080/orders/return/${id}`);
      }
      setMessage("Return request(s) submitted successfully.");
    } catch (err) {
      console.error("Error submitting return request:", err);
      setMessage("Failed to submit return request.");
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Request Return</h2>
      <p><strong>Customer:</strong> {fullName}</p>

      {orders.length === 0 ? (
        <p>No orders found.</p>
      ) : (
        <form>
          <ul>
            {orders.map(order => (
              <li key={order.orderId}>
                <label>
                  <input
                    type="checkbox"
                    checked={!!selectedOrders[order.orderId]}
                    onChange={() => toggleSelection(order.orderId)}
                  />
                  {order.productName} (Order #{order.orderId}) — Qty: {order.quantity} | Status: {order.status}
                </label>
              </li>
            ))}
          </ul>
          <button type="button" onClick={handleSubmit}>Submit Return Request</button>
        </form>
      )}

      {message && <p>{message}</p>}
    </div>
  );
}
