import React, { useState, useEffect, useRef } from 'react';
import { useLocation, Navigate, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/CustomerHome.css';

export default function CustomerHome() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const username = state?.username || 'Customer';

  const [redirect, setRedirect] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef(null);

  const [profile, setProfile] = useState({
    firstName: '',
    lastName: '',
    email: ''
  });

  const [orderNotification, setOrderNotification] = useState('');
  const [latestOrder, setLatestOrder] = useState(null);

  useEffect(() => {
    const userData = localStorage.getItem(username);
    if (userData) {
      const parsed = JSON.parse(userData);
      setProfile({
        firstName: parsed.firstName || '',
        lastName: parsed.lastName || '',
        email: parsed.email || ''
      });
    }
  }, [username]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchLatestOrder = () => {
      axios.get(`http://localhost:8080/orders/latest/${username}`)
        .then(res => {
          setLatestOrder(res.data);
          localStorage.setItem("latestOrderStatus", JSON.stringify(res.data));
          if (res.data.notification) {
            setOrderNotification(res.data.notification);
          }
        })
        .catch(err => console.error("Failed to fetch latest order:", err));
    };

    fetchLatestOrder();
    const interval = setInterval(fetchLatestOrder, 10000);
    return () => clearInterval(interval);
  }, [username]);

  const handleOrderStatusClick = () => {
    navigate("/order-status");
  };

  // ✅ Updated to pass full name to Request Return page
  const handleRequestReturnClick = () => {
    navigate("/request-return", {
      state: {
        username,
        firstName: profile.firstName,
        lastName: profile.lastName
      }
    });
  };

  if (redirect) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="customer-home">
      <aside className="customer-sidebar">
        <h2 className="customer-menu-title">Customer Menu</h2>
        <nav className="customer-menu-nav">
          <a href="/customer" className="customer-menu-link">Give Order</a>
          <button className="customer-menu-link" onClick={handleOrderStatusClick}>Order Status</button>
          <a href="/order-track" className="customer-menu-link">Order Track</a>
          <button className="customer-menu-link" onClick={handleRequestReturnClick}>Request Return</button>
        </nav>
      </aside>

      <div className="customer-main-content">
        <div className="customer-content">
          <header className="page-header">
            <h1>Welcome, {username}!</h1>
            <div className="profile-wrapper" ref={dropdownRef}>
              <img
                src="/default-profile.png"
                alt="Profile"
                className="profile-icon"
                onClick={() => setShowDropdown(!showDropdown)}
              />
              {showDropdown && (
                <div className="profile-dropdown">
                  <div className="profile-details">
                    <p><strong>Name:</strong> {profile.firstName} {profile.lastName}</p>
                    <p><strong>Email:</strong> {profile.email}</p>
                    <p><strong>Username:</strong> {username}</p>
                  </div>
                  <hr />
                  <button onClick={() => setRedirect(true)}>Logout</button>
                </div>
              )}
            </div>
          </header>

          {orderNotification && (
            <div className="order-notification">
              <p><strong>Order Update:</strong> {orderNotification}</p>
            </div>
          )}

          {latestOrder && (
            <section className="order-status-section">
              <h2>Latest Order Status</h2>
              <p><strong>Order ID:</strong> {latestOrder.orderId}</p>
              <p><strong>Product:</strong> {latestOrder.productName}</p>
              <p><strong>Status:</strong> {latestOrder.status}</p>
              {latestOrder.status === "REJECTED" && (
                <p><strong>Reason:</strong> {latestOrder.rejectionReason}</p>
              )}
            </section>
          )}

          <main className="customer-main">
            <h2>Customer Dashboard</h2>
            <p>
              This is your home page. From here you can access your profile, view
              orders, and manage your account.
            </p>
          </main>

          <section className="services-section">
            <h2>Our Services</h2>
            <div className="service-item">
              <div className="service-content">
                <h3>Express Parcel</h3>
                <p>
                  Rapid technical breakthroughs, changing customer expectations and strong government investments in infrastructure are all driving a revolutionary change in India's express logistics and parcel delivery industry...
                </p>
              </div>
            </div>
            <div className="service-item">
              <div className="service-content1">
                <h3>Warehousing</h3>
                <p>
                  A warehouse is a commercial building designed for the storage of goods...
                </p>
              </div>
            </div>
          </section>

          <section className="info-section">
            <h2>Support</h2>
            <p>
              Our 24/7 support team is here to help with onboarding, troubleshooting, and custom integrations. Chat or email us anytime.
            </p>
          </section>

          <section className="info-section1">
            <h2>Our Locations</h2>
            <ol>
              <li>Chennai (Headquarters)</li>
              <li>Bengaluru Warehouse</li>
              <li>Delhi Distribution Center</li>
            </ol>
          </section>

          <footer className="page-footer">
            <div className="footer-links">
              <button>Warehousing</button>
              <button>Management</button>
              <button>Support</button>
            </div>
            <p>© 2025 MyApp. All rights reserved.</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
