import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import '../styles/ReturnItems.css'; // Link to the CSS file

export default function ReturnItems() {
  const { state } = useLocation();
  const username = state?.username || '';
  const [orders, setOrders] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (username) {
      axios.get(`http://localhost:8080/orders/my-orders/${username}`)
        .then(res => setOrders(res.data))
        .catch(err => console.error("Failed to fetch orders:", err));
    }
  }, [username]);

  const handleReturn = (orderId) => {
    axios.post(`http://localhost:8080/orders/return/${orderId}`)
      .then(() => setMessage(`✅ Return request submitted for Order ID ${orderId}`))
      .catch(() => setMessage(`❌ Failed to submit return for Order ID ${orderId}`));
  };

  return (
    <div className="return-items-container">
      <h1 className="return-title">Return Items</h1>
      <p className="return-subtitle">Logged in as: <strong>{username}</strong></p>
      {message && <div className="return-message">{message}</div>}

      {orders.length > 0 ? (
        <div className="order-list">
          {orders.map(order => (
            <div key={order.orderId} className="order-card">
              <p><strong>Order ID:</strong> {order.orderId}</p>
              <p><strong>Product:</strong> {order.productName}</p>
              <p><strong>Status:</strong> {order.status}</p>
              {order.status === "DELIVERED" ? (
                <button className="return-button" onClick={() => handleReturn(order.orderId)}>
                  Return This Item
                </button>
              ) : (
                <p className="not-eligible">Not eligible for return</p>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="no-orders">No orders found for this user.</p>
      )}
    </div>
  );
}
