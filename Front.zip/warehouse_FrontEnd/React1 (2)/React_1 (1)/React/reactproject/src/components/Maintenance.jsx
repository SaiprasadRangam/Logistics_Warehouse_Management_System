import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/Maintenance.css';

function Maintenance() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({
    equipmentId: '',
    taskDescription: '',
    scheduledDate: '',
    completionStatus: ''
  });

  const navigate = useNavigate();

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: name === 'equipmentId' ? Number(value) : value
    }));
  };

  const scheduleTask = async () => {
    const { equipmentId, taskDescription, scheduledDate, completionStatus } = form;

    if (!equipmentId || !taskDescription || !scheduledDate || !completionStatus) {
      alert('Please fill in all fields');
      return;
    }

    try {
      await axios.post('http://localhost:8080/maintenance/schedule', form, {
        headers: { 'Content-Type': 'application/json' }
      });

      setForm({
        equipmentId: '',
        taskDescription: '',
        scheduledDate: '',
        completionStatus: ''
      });

      fetchTasks();
    } catch (error) {
      console.error('Error scheduling task:', error.response?.data || error.message);
    }
  };

  const fetchTasks = async () => {
    try {
      const res = await axios.get('http://localhost:8080/maintenance/viewMaintenance');
      setTasks(res.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div className="module-container">
      <div className="maintenance-header">
        <h2>Maintenance Scheduling</h2>
        <button className="home-button" onClick={() => navigate('/sidebar')}>🏠 Home</button>
      </div>

      <div className="form-group">
        <input
          name="equipmentId"
          type="number"
          placeholder="Equipment ID"
          value={form.equipmentId}
          onChange={handleChange}
        />
        <input
          name="taskDescription"
          placeholder="Task Description"
          value={form.taskDescription}
          onChange={handleChange}
        />
        <input
          name="scheduledDate"
          type="date"
          value={form.scheduledDate}
          onChange={handleChange}
        />
        <input
          name="completionStatus"
          placeholder="Status"
          value={form.completionStatus}
          onChange={handleChange}
        />
        <button onClick={scheduleTask}>Schedule</button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Equipment</th>
            <th>Task</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((t, index) => (
            <tr key={index}>
              <td>{t.equipmentId}</td>
              <td>{t.taskDescription}</td>
              <td>{t.scheduledDate}</td>
              <td>{t.completionStatus}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Maintenance;
