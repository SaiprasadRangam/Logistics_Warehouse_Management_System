import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/Inventory.css';
import '../styles/buttoncolors.css';

function Inventory() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({
    itemName: '',
    category: '',
    quantity: '',
    location: ''
  });
  const [editId, setEditId] = useState(null);
  const [editForm, setEditForm] = useState({
    itemName: '',
    category: '',
    quantity: '',
    location: ''
  });
  const [showInventory, setShowInventory] = useState(true);

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = () => {
    axios.get('http://localhost:8080/inventory/viewInventory')
      .then(res => setItems(res.data))
      .catch(err => console.error('Error fetching inventory:', err));
  };

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleEditChange = e => setEditForm({ ...editForm, [e.target.name]: e.target.value });

  const addItem = () => {
  const nameRegex = /^[A-Za-z\s]+$/;
  if (!nameRegex.test(form.itemName)) {
    alert('Item Name must contain only alphabets');
    return;
  }

  const newItem = {
    ...form,
    quantity: parseInt(form.quantity)
  };

  axios.post('http://localhost:8080/inventory/addInventory', newItem)
    .then(() => {
      setForm({ itemName: '', category: '', quantity: '', location: '' });
      fetchInventory();
    })
    .catch(err => console.error('Error adding item:', err));
};


  const removeItem = id => {
    axios.delete(`http://localhost:8080/inventory/deleteInventory/${id}`)
      .then(() => fetchInventory())
      .catch(err => console.error('Error deleting item:', err));
  };

  const startEdit = item => {
    setEditId(item.itemId);
    setEditForm({
      itemName: item.itemName,
      category: item.category,
      quantity: item.quantity,
      location: item.location
    });
  };

 const updateItem = id => {
  const nameRegex = /^[A-Za-z\s]+$/;
  if (!nameRegex.test(editForm.itemName)) {
    alert('Item Name must contain only alphabets');
    return;
  }
  if (!categoryRegex.test(editForm.category)) {
    alert('Category must contain only alphabets');
    return;
  }
  if (!/^\d+$/.test(form.quantity)) {
    alert('Quantity must be a valid number');
    return;
  }
  const updatedItem = {
    ...editForm,
    quantity: parseInt(editForm.quantity)
  };

  axios.put(`http://localhost:8080/inventory/updateInventory/${id}`, updatedItem)
    .then(() => {
      setEditId(null);
      setEditForm({ itemName: '', category: '', quantity: '', location: '' });
      fetchInventory();
    })
    .catch(err => console.error('Error updating item:', err));
};


  const toggleInventory = () => setShowInventory(prev => !prev);

  return (
    <div className="module">
      <div className="inventory-header">
        <h2>Inventory Management</h2>
        <button className="home-button" onClick={() => navigate('/sidebar')}>🏠 Home</button>
      </div>

      <div className="outer-container">
        <div className="form-table-wrapper">
          <div className="form-group">
            <input name="itemName" placeholder="Item Name" value={form.itemName} onChange={handleChange} />
            <input name="category" placeholder="Category" value={form.category} onChange={handleChange} />
            <input name="quantity" type="number" placeholder="Quantity" value={form.quantity} onChange={handleChange} />
            <input name="location" placeholder="Location" value={form.location} onChange={handleChange} />
            <div className="button-row">
              <button className="primary-button" onClick={addItem}>Add</button>
              <button className="toggle-button" onClick={toggleInventory}>
                {showInventory ? 'Hide Inventory' : 'Show Inventory'}
              </button>
            </div>
          </div>
        </div>

        {showInventory && (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Qty</th>
                <th>Location</th>
                <th>Last Updated</th>
                
              </tr>
            </thead>
            <tbody>
              {items.map(i => (
                <tr key={i.itemId}>
                  {editId === i.itemId ? (
                    <>
                      <td>{i.itemId}</td>
                      <td><input name="itemName" value={editForm.itemName} onChange={handleEditChange} /></td>
                      <td><input name="category" value={editForm.category} onChange={handleEditChange} /></td>
                      <td><input name="quantity" type="number" value={editForm.quantity} onChange={handleEditChange} /></td>
                      <td><input name="location" value={editForm.location} onChange={handleEditChange} /></td>
                      <td>{i.lastUpdated?.replace('T', ' ').slice(0, 19)}</td>
                      <td>
                        <button className="update-button" onClick={() => updateItem(i.itemId)}>Save</button>
                        <button className="cancel-button" onClick={() => setEditId(null)}>Cancel</button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td>{i.itemId}</td>
                      <td>{i.itemName}</td>
                      <td>{i.category}</td>
                      <td>{i.quantity}</td>
                      <td>{i.location}</td>
                      <td>{i.lastUpdated?.replace('T', ' ').slice(0, 19)}</td>
                      <td>
                        <button className="edit-button" onClick={() => startEdit(i)}>Edit</button>
                        <button className="danger-button" onClick={() => removeItem(i.itemId)}>Remove</button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Inventory;
