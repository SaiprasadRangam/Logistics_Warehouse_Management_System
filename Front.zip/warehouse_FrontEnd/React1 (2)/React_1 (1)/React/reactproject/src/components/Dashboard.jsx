import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Dashboard.css';

function Dashboard() {
  const stats = [
    { label: 'Total Shipments', icon: '🚚' },
    { label: 'Inventory Accuracy', icon: '📦' },
    { label: 'Warehouse Utilization', icon: '🏢' },
    { label: 'Avg. Maintenance Time', icon: '🛠️' },
    { label: 'Reports Generated', icon: '📈' }
  ];

  const navigate = useNavigate();
  const location = window.location;
  let email = '';
  if (location && location.state && location.state.email) {
    email = location.state.email;
  } else if (window.history && window.history.state && window.history.state.usr && window.history.state.usr.email) {
    email = window.history.state.usr.email;
  }

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="logo">SmartOps LWMS</div>
        {email && (
          <div style={{ color: '#0077cc', fontWeight: 600, fontSize: '1.1rem', marginLeft: '20px' }}>
            Welcome, {email}!
          </div>
        )}
        <nav className="nav-bar">
          <button className="nav-button" onClick={() => navigate('/login')}>
            <span className="nav-label">Login / Signup</span>
          </button>
        </nav>
      </header>

      <section className="about-section">
        <p>
          Smart Ops is a cutting-edge Warehouse Management System (WMS) designed to optimize your supply chain with real-time visibility and streamlined order fulfillment.
        </p>
      </section>

      <section className="stats-container white-bg">
        <h3>📊 Application Statistics</h3>
        <div className="stats-grid">
          {stats.map(stat => (
            <div key={stat.label} className="stat-card">
              <span className="stat-icon">{stat.icon}</span>
              <h4>{stat.label}</h4>
              <p>{stat.value}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services-section">
        <h2>Our Services</h2>
        <div className="service-item">
          <div className="service-content">
            <h3>Express Parcel</h3>
            <p>
              Rapid technical breakthroughs, changing customer expectations and strong government investments in infrastructure are all driving a revolutionary change in India's express logistics and parcel delivery industry.
            </p>
          </div>
        </div>
        <div className="service-item">
          <div className="service-content">
            <h3>Warehousing</h3>
            <p>
              A warehouse is a commercial building designed for the storage of goods. It serves as a pivotal space where products are kept safe until they are transported to retailers, distributors, or directly to customers.
            </p>
          </div>
        </div>
      </section>

      <section className="info-section">
        <h2>Support</h2>
        <p>
          Our 24/7 support team is here to help with onboarding, troubleshooting, and custom integrations. Chat or email us anytime.
        </p>
      </section>

      <section className="info-section">
        <h2>Our Locations</h2>
        <ol>
          <p>Chennai (Headquarters)</p>
          <p>Bengaluru Warehouse</p>
          <p>Delhi Distribution Center</p>
        </ol>
      </section>

      <section className="about-cards-section">
        <div className="about-cards">
          <div className="about-card transparent">
            <span className="card-icon">🚀</span>
            <h3>D2C Brands</h3>
            <p>Empowering direct-to-consumer businesses with a seamless logistics ecosystem.</p>
          </div>
          <div className="about-card transparent">
            <span className="card-icon">📦</span>
            <h3>Personal Courier</h3>
            <p>India’s first and only online courier platform tailored for personal shipments.</p>
          </div>
          <div className="about-card transparent">
            <span className="card-icon">🏭</span>
            <h3>B2B Enterprises</h3>
            <p>End-to-end logistics solutions designed for enterprise supply chains.</p>
          </div>
        </div>
      </section>

      <footer className="dashboard-footer">
        <div className="footer-content">
          <div className="footer-contact">
            <h4>Contact Us</h4>
            <p>Email: support@smartops.com</p>
            <p>Phone: +91 98765 43210</p>
            <p>Business Hours: Mon–Sat, 9:00 AM – 6:00 PM</p>
          </div>
          <div className="footer-address">
            <h4>Corporate Office</h4>
            <p>SmartOps Inc.</p>
            <p>Plot No. 42, SIPCOT IT Park</p>
            <p>Thiruporur, Tamil Nadu – 603110</p>
          </div>
          <div className="footer-links">
           
            <ul>
              <li><a href="/privacy">Privacy Policy</a></li>
              <li><a href="/terms">Terms of Service</a></li>
              <li><a href="/faq">FAQs</a></li>
              <li><a href="/contact">Contact Form</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} SmartOps Inc. | All rights reserved</p>
        </div>
      </footer>
    </div>
  );
}

export default Dashboard;
