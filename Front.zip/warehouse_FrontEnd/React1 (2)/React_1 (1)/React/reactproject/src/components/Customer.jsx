import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import '../styles/Customer.css';

function Customer() {
  const { state } = useLocation();
  const [customerName, setCustomerName] = useState('');
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [address, setAddress] = useState('');
  const [orderMessage, setOrderMessage] = useState('');

  // Load customer name from state or localStorage
  useEffect(() => {
    if (state?.customerName) {
      setCustomerName(state.customerName);
      localStorage.setItem('currentCustomerName', state.customerName);
    } else {
      const storedName = localStorage.getItem('currentCustomerName');
      if (storedName) {
        setCustomerName(storedName);
      }
    }
  }, [state]);

  const handleOrder = async (e) => {
    e.preventDefault();

    if (!productName.trim() || !quantity || !address.trim()) {
      setOrderMessage('⚠️ Please fill in all fields.');
      return;
    }

    const orderData = {
      productName: productName.trim(),
      customerName,
      quantity: parseInt(quantity, 10),
      address: address.trim(),
      status: 'PENDING'
    };

    try {
      await axios.post('http://localhost:8080/orders/place', orderData);
      setOrderMessage('✅ Order placed successfully!');
      setProductName('');
      setQuantity('');
      setAddress('');
    } catch (err) {
      console.error('Order failed:', err);
      setOrderMessage('❌ Failed to place order. Please try again.');
    }
  };

  return (
    <div className="customer-inventory-container">
      <h2 className="order-title">🛒 Place an Order</h2>
      <form className="order-form" onSubmit={handleOrder}>
        <div className="form-group">
          <label htmlFor="productName">Product Name:</label>
          <input
            id="productName"
            type="text"
            value={productName}
            onChange={e => setProductName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="customerName">Customer Name:</label>
          <input
            id="customerName"
            type="text"
            value={customerName}
            readOnly
          />
        </div>

        <div className="form-group">
          <label htmlFor="quantity">Quantity:</label>
          <input
            id="quantity"
            type="number"
            min="1"
            value={quantity}
            onChange={e => setQuantity(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="address">Address:</label>
          <input
            id="address"
            type="text"
            value={address}
            onChange={e => setAddress(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="submit-btn">Place Order</button>
      </form>

      {orderMessage && <p className="order-message">{orderMessage}</p>}
    </div>
  );
}

export default Customer;
