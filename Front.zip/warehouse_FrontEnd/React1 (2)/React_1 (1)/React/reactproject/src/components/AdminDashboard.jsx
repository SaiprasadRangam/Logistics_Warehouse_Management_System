import axios from 'axios';
import { useState, useEffect } from 'react';
import '../styles/AdminDashboard.css';

function AdminDashboard() {
  const [orders, setOrders] = useState([]);
  const [message, setMessage] = useState("");
  const [view, setView] = useState("requests");

  useEffect(() => {
    refreshOrders();
  }, []);

  const refreshOrders = () => {
    axios.get("http://localhost:8080/orders/all")
      .then(res => setOrders(res.data))
      .catch(err => console.error("Failed to fetch orders:", err));
  };

  const handleApprove = async (orderId) => {
    try {
      await axios.put(`http://localhost:8080/orders/updateStatus/${orderId}`, {
        status: "APPROVED"
      });
      setMessage(`Order #${orderId} approved`);
      refreshOrders();
    } catch (error) {
      console.error("Approval failed:", error);
      setMessage("Failed to approve order");
    }
  };

  const handleReject = async (orderId) => {
    const reason = prompt("Enter rejection reason:");
    if (!reason) return;

    try {
      await axios.put(`http://localhost:8080/orders/updateStatus/${orderId}`, {
        status: "REJECTED",
        rejectionReason: reason
      });
      setMessage(`Order #${orderId} rejected`);
      refreshOrders();
    } catch (error) {
      console.error("Rejection failed:", error);
      setMessage("Failed to reject order");
    }
  };

  const filteredOrders = orders.filter(order => {
    if (view === "requests") return order.status === "PENDING";
    if (view === "history") return order.status !== "PENDING";
    return true;
  });

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>

      <nav className="admin-nav">
        <button onClick={() => setView("requests")} className={view === "requests" ? "active" : ""}>Requests</button>
        <button onClick={() => setView("history")} className={view === "history" ? "active" : ""}>History</button>
      </nav>

      {message && <p className="admin-message">{message}</p>}

      <div className="order-card-container">
        {filteredOrders.map(order => (
          <div key={order.orderId} className="order-card">
            <h3>Order #{order.orderId}</h3>
            <p><strong>Customer Name:</strong> {order.customerName}</p>
            <p><strong>Product:</strong> {order.productName}</p>
            <p><strong>Quantity:</strong> {order.quantity}</p>
            <p><strong>Address:</strong> {order.address}</p>
            <p><strong>Status:</strong> {order.status}</p>
            {order.rejectionReason && <p><strong>Rejection Reason:</strong> {order.rejectionReason}</p>}
            {view === "requests" && (
              <div className="card-actions">
                <button onClick={() => handleApprove(order.orderId)}>Approve</button>
                <button onClick={() => handleReject(order.orderId)}>Reject</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default AdminDashboard;
