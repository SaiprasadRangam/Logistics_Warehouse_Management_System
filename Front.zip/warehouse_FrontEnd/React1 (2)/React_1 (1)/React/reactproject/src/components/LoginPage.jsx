import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/LoginPage.css';

function LoginPage() {
  const navigate = useNavigate();
  const [isSignup, setIsSignup] = useState(false);
  const [role, setRole] = useState('customer');
  const [form, setForm] = useState({
    username: '',
    password: '',
    mobile: '',
    email: '',
    firstName: '',
    lastName: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const validateEmailDomain = (email) => {
    const allowedDomains = ['@gmail.com', '@yahoo.com', '@outlook.com'];
    const domain = email.substring(email.lastIndexOf('@'));
    return allowedDomains.includes(domain);
  };

  const validateSignup = () => {
    const newErrors = {};
    if (!/^[6-9]\d{9}$/.test(form.mobile)) {
      newErrors.mobile = 'Mobile must start with 6-9 and be exactly 10 digits';
    }
    if (
      !/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(form.password)
    ) {
      newErrors.password = 'Password needs 8+ chars, letters, numbers & special chars';
    }
    if (role === 'customer') {
      if (!form.email.trim()) {
        newErrors.email = 'Email is required for customer signup';
      } else if (!validateEmailDomain(form.email)) {
        newErrors.email = 'Email must end with @gmail.com, @yahoo.com, or @outlook.com';
      }
      if (!form.firstName.trim()) {
        newErrors.firstName = 'First name is required';
      }
      if (!form.lastName.trim()) {
        newErrors.lastName = 'Last name is required';
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateLogin = () => {
    const newErrors = {};
    if (!form.username.trim()) newErrors.username = 'Username is required';
    if (!form.password) newErrors.password = 'Password is required';
    if (role === 'customer') {
      if (!form.email.trim()) {
        newErrors.email = 'Email is required for customer login';
      } else if (!validateEmailDomain(form.email)) {
        newErrors.email = 'Email must end with @gmail.com, @yahoo.com, or @outlook.com';
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (isSignup) {
      if (!validateSignup()) return;

      localStorage.setItem(form.username, JSON.stringify({
        username: form.username,
        password: form.password,
        mobile: form.mobile,
        role,
        email: role === 'customer' ? form.email : '',
        firstName: role === 'customer' ? form.firstName : '',
        lastName: role === 'customer' ? form.lastName : ''
      }));
      alert('Account created successfully!');
      setIsSignup(false);
      setForm({
        username: '',
        password: '',
        mobile: '',
        email: '',
        firstName: '',
        lastName: ''
      });
      return;
    } else {
      if (!validateLogin()) return;

      const userData = localStorage.getItem(form.username);
      if (!userData) {
        setErrors({ username: 'User not found' });
        return;
      }
      const parsed = JSON.parse(userData);
      if (parsed.password !== form.password) {
        setErrors({ password: 'Incorrect password' });
        return;
      }
      if (role === 'customer' && parsed.email !== form.email) {
        setErrors({ email: 'Email does not match our records' });
        return;
      }

     const fullName = `${parsed.firstName} ${parsed.lastName}`;
localStorage.setItem('currentCustomerName', fullName);

if (parsed.role === 'employee') {
  navigate('/sidebar', {
    state: {
      username: form.username
    }
  });
} else {
  navigate('/customerHome', {
    state: {
      username: form.username,
      customerName: fullName
    }
  });


}

    }
  };

  return (
    <div className="auth-background">
      <div className="login-container">
        <form className="login-form" onSubmit={e => { e.preventDefault(); handleSubmit(); }}>
          <h2 className="login-title">{isSignup ? 'Sign Up' : 'Login'}</h2>

          <div className="role-toggle">
            <label>
              <input
                type="radio"
                name="role"
                value="customer"
                checked={role === 'customer'}
                onChange={() => setRole('customer')}
              /> Customer
            </label>
            <label>
              <input
                type="radio"
                name="role"
                value="employee"
                checked={role === 'employee'}
                onChange={() => setRole('employee')}
              /> Employee
            </label>
          </div>

          <input
            name="username"
            placeholder="Username"
            value={form.username}
            onChange={handleChange}
            required
            className="login-input"
          />
          {errors.username && <p className="error">{errors.username}</p>}

          <input
            name="password"
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            required
            className="login-input"
          />
          {errors.password && <p className="error">{errors.password}</p>}

          {isSignup && (
            <>
              <input
                name="mobile"
                placeholder="Mobile Number"
                value={form.mobile}
                onChange={handleChange}
                required
                className="login-input"
              />
              {errors.mobile && <p className="error">{errors.mobile}</p>}
            </>
          )}

          {(isSignup && role === 'customer') || (!isSignup && role === 'customer') ? (
            <>
              {isSignup && (
                <>
                  <input
                    name="firstName"
                    placeholder="First Name"
                    value={form.firstName}
                    onChange={handleChange}
                    required
                    className="login-input"
                  />
                  {errors.firstName && <p className="error">{errors.firstName}</p>}

                  <input
                    name="lastName"
                    placeholder="Last Name"
                    value={form.lastName}
                    onChange={handleChange}
                    required
                    className="login-input"
                  />
                  {errors.lastName && <p className="error">{errors.lastName}</p>}
                </>
              )}

              <input
                name="email"
                type="email"
                placeholder="Email"
                value={form.email}
                onChange={handleChange}
                required
                className="login-input"
              />
              {errors.email && <p className="error">{errors.email}</p>}
            </>
          ) : null}

          <button type="submit" className="login-btn">
            {isSignup ? 'Sign Up' : 'Login'}
          </button>

          <p className="toggle-text">
            {isSignup ? 'Already have an account?' : 'New user?'}{' '}
            <span onClick={() => setIsSignup(!isSignup)} className="toggle-link">
              {isSignup ? 'Login here' : 'Sign up here'}
            </span>
          </p>
        </form>
      </div>

      <footer className="page-footer">
        <p>© 2025 MyApp. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default LoginPage;
