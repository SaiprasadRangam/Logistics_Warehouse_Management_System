package com.example.demo.Service;

import com.example.demo.Entity.Report;
import com.example.demo.Repo.ReportRepo;
import com.example.demo.ExceptionHandler.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReportService {

    private final ReportRepo repository;

    public ReportService(ReportRepo repository) {
        this.repository = repository;
    }


    public Report generateReport(Report report) {
        report.setGeneratedOn(LocalDateTime.now());
        return repository.save(report);
    }


    public Report getReportById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found with id: " + id));
    }


    public List<Report> getAllReports() {

        return repository.findAll();
    }
}
