
package com.example.demo.Repo;

import com.example.demo.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

//public interface UserRepository<User> extends CrudRepository<User, String> {
//    User findByUsername(String username);
//}

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);

    User findByEmail(String email);
}
