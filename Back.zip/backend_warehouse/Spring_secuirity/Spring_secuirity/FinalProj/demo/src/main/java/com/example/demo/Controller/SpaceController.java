package com.example.demo.Controller;

import com.example.demo.Entity.Space;
import com.example.demo.Service.SpaceServices;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/space")
@CrossOrigin(origins = "http://localhost:5173")
public class SpaceController {
    private final SpaceServices service;

    public SpaceController(SpaceServices service) {
        this.service = service;
    }

    @GetMapping("/view")
    public ResponseEntity<List<Space>> viewSpaceUsage() {
        return ResponseEntity.ok(service.viewSpaceUsage());
    }

    @PostMapping("/create")
    public ResponseEntity<Space> createSpace(@RequestBody Space space) {
        return ResponseEntity.ok(service.createSpace(space));
    }

    @PostMapping("/allocate/{id}")
    public ResponseEntity<Space> allocateSpace(@PathVariable Long id, @RequestParam Double volume) {
        return ResponseEntity.ok(service.allocateSpace(id, volume));
    }

    @PostMapping("/free/{id}")
    public ResponseEntity<Space> freeSpace(@PathVariable Long id, @RequestParam Double volume) {
        return ResponseEntity.ok(service.freeSpace(id, volume));
    }
}
