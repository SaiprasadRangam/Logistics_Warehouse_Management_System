package com.example.demo.Controller;

import com.example.demo.Entity.Shipment;
import com.example.demo.Service.ShipmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/shipments")
public class ShipmentController {

    private final ShipmentService service;

    public ShipmentController(ShipmentService service) {
        this.service = service;
    }


    @PostMapping("/received")
    public ResponseEntity<String> receiveShipment(@Valid @RequestBody Shipment shipment) {
        service.receiveShipment(shipment);
        return ResponseEntity.ok("Received Shipment");
    }


    @PutMapping("/dispatch/{id}")
    public ResponseEntity<String> dispatchShipment(@PathVariable Long id) {
        service.dispatchShipment(id);
        return ResponseEntity.ok("Dispatched");
    }


    @GetMapping("/track/{id}")
    public ResponseEntity<Shipment> trackShipment(@PathVariable Long id) {
        Shipment shipments=service.trackShipment(id);
        return ResponseEntity.ok(shipments);
    }

    //
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Shipment>> getShipmentsByStatus(@PathVariable String status) {
        return ResponseEntity.ok(service.getShipmentsByStatus(status));
    }
}
