package com.example.demo.Repo;

import com.example.demo.Entity.LwmsUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LwmsUserRepository extends JpaRepository<LwmsUser, Long> {
    Optional<LwmsUser> findByUsername(String username);
    boolean existsByUsername(String username);
}
