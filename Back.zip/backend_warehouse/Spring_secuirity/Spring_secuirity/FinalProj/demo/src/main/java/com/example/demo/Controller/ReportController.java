package com.example.demo.Controller;

import com.example.demo.Entity.Report;
import com.example.demo.Service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/reports")
public class ReportController {

    private final ReportService service;

    public ReportController(ReportService service) {

        this.service = service;
    }

    // Generate a new report
    @PostMapping("/generate")
    public ResponseEntity<String> generateReport(
            @Valid @RequestBody Report report) {
        service.generateReport(report);
        return ResponseEntity.ok("Generated");
    }

    // Download or view a report by ID
    @GetMapping("/reports/{id}")
    public ResponseEntity<Report> getReport(@PathVariable Long id) {
        Report report = service.getReportById(id);
        return ResponseEntity.ok(report);
    }

    // View all reports
    @GetMapping("/reports")
    public ResponseEntity<List<Report>> getAllReports() {
        return ResponseEntity.ok(service.getAllReports());
    }
}