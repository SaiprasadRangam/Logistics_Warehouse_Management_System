package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "Space")
public class Space {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long spaceId;

    @NotNull(message = "Total capacity is required")
    @Positive(message = "Total capacity must be greater than zero")
    private Double totalCapacity;

    @NotNull(message = "Used capacity is required")
    @PositiveOrZero(message = "Used capacity cannot be negative")
    private Double usedCapacity;

    @NotNull(message = "Available capacity is required")
    @PositiveOrZero(message = "Available capacity cannot be negative")
    private Double availableCapacity;

    @NotBlank(message = "Zone is required")
    private String zone;

    public Space(Long spaceId, Double totalCapacity, Double usedCapacity, Double availableCapacity, String zone) {
        this.spaceId = spaceId;
        this.totalCapacity = totalCapacity;
        this.usedCapacity = usedCapacity;
        this.availableCapacity = availableCapacity;
        this.zone = zone;
    }

    public Space() {
    }

    public Long getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(Long spaceId) {
        this.spaceId = spaceId;
    }

    public Double getTotalCapacity() {
        return totalCapacity;
    }

    public void setTotalCapacity(Double totalCapacity) {
        this.totalCapacity = totalCapacity;
    }

    public Double getUsedCapacity() {
        return usedCapacity;
    }

    public void setUsedCapacity(Double usedCapacity) {
        this.usedCapacity = usedCapacity;
    }

    public Double getAvailableCapacity() {
        return availableCapacity;
    }

    public void setAvailableCapacity(Double availableCapacity) {
        this.availableCapacity = availableCapacity;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }
}
