package com.example.demo.Entity;

import  jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Report")
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;

    @NotBlank(message = "Report type is required")
    private String reportType; // e.g., INVENTORY_TURNOVER, SPACE_UTILIZATION

    @NotNull(message = "GeneratedOn date is required")
    private LocalDateTime generatedOn;

    @NotBlank(message = "Report details are required")
    @Column(columnDefinition = "TEXT")
    private String details; // Could store JSON, summaries, KPIs, etc.

    public Report(Long reportId, String reportType, LocalDateTime generatedOn, String details) {

        this.reportId = reportId;
        this.reportType = reportType;
        this.generatedOn = generatedOn;
        this.details = details;
    }

    public Report() {
    }

    public Long getReportId() {
        return reportId;
    }

    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public LocalDateTime getGeneratedOn() {
        return generatedOn;
    }

    public void setGeneratedOn(LocalDateTime generatedOn) {
        this.generatedOn = generatedOn;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}

