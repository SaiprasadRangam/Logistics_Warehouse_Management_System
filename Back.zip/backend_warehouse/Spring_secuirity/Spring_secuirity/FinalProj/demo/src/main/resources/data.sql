--INSERT INTO Inventory (item_name, category, quantity, location, last_updated) VALUES
--('Forklift Battery', 'Equipment', 10, 'Zone A', NOW()),
--('Steel Beams', 'Construction', 50, 'Zone B', NOW()),
--('Packing Boxes', 'Supplies', 200, 'Zone C', NOW()),
--('Pallet Jack', 'Equipment', 15, 'Zone D', NOW()),
--('LED Lights', 'Electrical', 75, 'Zone E', NOW()),
--('PVC Pipes', 'Plumbing', 120, 'Zone F', NOW()),
--('Safety Helmets', 'Safety', 300, 'Zone G', NOW()),
--('Wooden Pallets', 'Logistics', 500, 'Zone H', NOW()),
--('Cement Bags', 'Construction', 90, 'Zone I', NOW()),
--('Extension Cords', 'Electrical', 45, 'Zone J', NOW());
--
--INSERT INTO Space (total_capacity, used_capacity, available_capacity, zone) VALUES
--(1000, 400, 600, 'Zone A'),
--(2000, 1500, 500, 'Zone B'),
--(1500, 1000, 500, 'Zone C'),
--(800,  600, 200, 'Zone D'),
--(1200, 900, 300, 'Zone E'),
--(1600, 800, 800, 'Zone F'),
--(1100, 550, 550, 'Zone G'),
--(900,  700, 200, 'Zone H'),
--(1400, 1200, 200, 'Zone I'),
--(1300, 1100, 200, 'Zone J');
--
--INSERT INTO shipment
--(shipment_id, destination, expected_delivery, origin, status, item_id)
--VALUES
--(1, 'Chennai',    '2025-08-25 14:00:00', 'Mumbai',     'IN_TRANSIT', 1),
--(2, 'Kolkata',    '2025-08-27 09:30:00', 'Delhi',      'DISPATCHED', 2),
--(3, 'Bengaluru',  '2025-08-20 10:00:00', 'Pune',       'RECEIVED',   3),
--(4, 'Hyderabad',  '2025-08-18 15:45:00', 'Jaipur',     'DELIVERED',  4),
--(5, 'Lucknow',    '2025-08-26 11:15:00', 'Ahmedabad',  'IN_TRANSIT', 5),
--(6, 'Nagpur',     '2025-08-29 16:00:00', 'Surat',      'DISPATCHED', 6),
--(7, 'Patna',      '2025-08-22 08:45:00', 'Indore',     'RECEIVED',   7),
--(8, 'Ranchi',     '2025-08-30 12:20:00', 'Bhopal',     'IN_TRANSIT', 8),
--(9, 'Coimbatore', '2025-08-19 09:50:00', 'Vizag',      'DELIVERED',  9),
--(10, 'Trivandrum','2025-09-01 17:10:00', 'Goa',        'PENDING',   10);

--
INSERT INTO Maintenance
(schedule_id, completion_status, equipment_id, scheduled_date, task_description)
VALUES
(1,  'PENDING',    101, '2025-08-25 09:00:00', 'Quarterly lubrication of conveyor belt'),
(2,  'COMPLETED',  102, '2025-08-20 14:30:00', 'Replace worn‑out pump seal'),
(3,  'IN_PROGRESS',103, '2025-08-22 11:00:00', 'Calibrate temperature sensors'),
(4,  'PENDING',    104, '2025-08-28 08:45:00', 'Inspect and clean air filters'),
(5,  'COMPLETED',  105, '2025-08-15 15:15:00', 'Test emergency stop buttons'),
(6,  'PENDING',    106, '2025-08-27 10:00:00', 'Upgrade machine firmware to latest version'),
(7,  'CANCELLED',  107, '2025-08-18 16:20:00', 'Replace hydraulic fluid'),
(8,  'COMPLETED',  108, '2025-08-19 13:30:00', 'Tighten loose conveyor motor mounts'),
(9,  'IN_PROGRESS',109, '2025-08-24 09:15:00', 'Inspect safety guards and sensors'),
(10, 'PENDING',    110, '2025-08-30 12:00:00', 'Check pressure levels in boilers');

--INSERT INTO Report (report_type, generated_on, details) VALUES
--('INVENTORY_TURNOVER', NOW(), 'Turnover increased 15% from last quarter.'),
--('SPACE_UTILIZATION', NOW(), 'Zone B nearing 80% capacity.'),
--('SHIPMENT_STATUS', NOW(), '92% shipments delivered on time this month.'),
--('MAINTENANCE_OVERVIEW', NOW(), '4 scheduled, 2 completed, 1 delayed tasks.'),
--('PERFORMANCE_SUMMARY', NOW(), 'Overall efficiency up 10% this month.'),
--('SAFETY_AUDIT', NOW(), 'No major hazards detected during safety check.'),
--('MONTHLY_COST', NOW(), 'Operational costs decreased by 5%.'),
--('DELIVERY_PERFORMANCE', NOW(), 'Average delivery time reduced to 3.2 days.'),
--('ASSET_HEALTH', NOW(), '80% equipment in good condition.'),
--('RESOURCE_ALLOCATION', NOW(), 'Staff allocation optimized for peak hours.');
