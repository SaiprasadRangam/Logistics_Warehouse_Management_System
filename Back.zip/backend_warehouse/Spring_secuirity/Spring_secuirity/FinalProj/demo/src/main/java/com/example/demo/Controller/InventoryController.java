package com.example.demo.Controller;

import com.example.demo.Entity.Inventory;
import com.example.demo.Service.InventoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController

@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/inventory")
public class InventoryController {

    private final InventoryService service;

    public InventoryController(InventoryService service) {
        this.service = service;
    }

    @PostMapping("/addInventory")
    public ResponseEntity<String> addItem(@Valid @RequestBody Inventory inventory) {
        service.addItem(inventory);
        return ResponseEntity.ok("Item Added");
    }

    @PutMapping("/updateInventory/{id}")
    public ResponseEntity<String> updateItem(@PathVariable Long id, @Valid @RequestBody Inventory inventory) {
        service.updateItem(id, inventory);
        return ResponseEntity.ok("Updated Item");
    }

    @DeleteMapping("/deleteInventory/{id}")
    public ResponseEntity<String> removeItem(@PathVariable Long id) {
        service.removeItem(id);
        return ResponseEntity.ok("Removed Item");
    }

    @GetMapping("/viewInventory")
    public ResponseEntity<List<Inventory>> viewInventory() {
        return ResponseEntity.ok(service.viewInventory());
    }
}
