package com.example.demo.Entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "Shipment")
public class Shipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shipmentId;


@NotNull(message = "Item ID is required")
@Min(value = 1, message = "Item ID must be greater than 0")
private long itemId;

    @NotBlank(message = "Origin is required")
    private String origin;

    @NotBlank(message = "Destination is required")
    private String destination;


    @NotBlank(message = "Status is required")
    private String status; // RECEIVED, DISPATCHED, IN_TRANSIT, DELIVERED

    @NotNull(message = "Expected delivery date is required")
    private LocalDate expectedDelivery;

    public Shipment(Long shipmentId, Long itemId, String origin, String destination, String status, LocalDate expectedDelivery) {
        this.shipmentId = shipmentId;
        this.itemId = itemId;
        this.origin = origin;
        this.destination = destination;
        this.status = status;
        this.expectedDelivery = expectedDelivery;
    }

    public Shipment() {

    }

    public Long getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(Long shipmentId) {
        this.shipmentId = shipmentId;
    }

    public long getItemId() {
        return itemId;
    }


    public void setItemId( long itemId) {
        this.itemId = itemId;
    }

    public String getOrigin() {
        return origin;
    }


    public void setOrigin(@NotBlank(message = "Origin is required") String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(@NotBlank(message = "Destination is required") String destination) {
        this.destination = destination;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getExpectedDelivery() {
        return expectedDelivery;
    }



    public void setExpectedDelivery(@NotNull(message = "Expected delivery date is required") LocalDate expectedDelivery) {
        this.expectedDelivery = expectedDelivery;
    }
}
