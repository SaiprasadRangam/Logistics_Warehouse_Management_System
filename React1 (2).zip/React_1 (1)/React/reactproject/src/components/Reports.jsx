import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/Report.css';

function Reports() {
  const [reports, setReports] = useState([]);
  const [form, setForm] = useState({
    reportType: '',
    details: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const generateReport = async () => {
    const { reportType, details } = form;

    if (!reportType.trim() || !details.trim()) {
      alert('Please fill in all fields');
      return;
    }

    const payload = {
      reportType,
      details,
      generatedOn: new Date().toISOString() // ISO format for LocalDateTime
    };

    try {
      await axios.post('http://localhost:8080/reports/generate', payload, {
        headers: { 'Content-Type': 'application/json' }
      });

      setForm({ reportType: '', details: '' });
      fetchReports();
    } catch (error) {
      console.error('Error generating report:', error.response?.data || error.message);
    }
  };

  const fetchReports = async () => {
    try {
      const res = await axios.get('http://localhost:8080/reports/reports');
      setReports(res.data);
    } catch (error) {
      console.error('Error fetching reports:', error);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  return (
    <div className="module-container">
      <div className="report-header">
        <h2>Performance Reporting</h2>
        <button className="home-button" onClick={() => navigate('/sidebar')}>🏠 Home</button>
      </div>

      <div className="form-group">
        <input
          name="reportType"
          placeholder="Report Type"
          value={form.reportType}
          onChange={handleChange}
        />
        <textarea
          name="details"
          placeholder="Report Details"
          value={form.details}
          onChange={handleChange}
        />
        <button onClick={generateReport}>Generate</button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Type</th>
            <th>Generated On</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((r) => (
            <tr key={r.reportId}>
              <td>{r.reportType}</td>
              <td>{new Date(r.generatedOn).toLocaleString()}</td>
              <td>{r.details}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Reports;
