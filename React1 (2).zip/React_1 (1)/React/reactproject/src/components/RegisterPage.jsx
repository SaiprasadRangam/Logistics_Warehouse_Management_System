import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/RegisterPage.css';

function RegisterPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phonenumber, setPhoneNumber] = useState('');

  const handleRegister = (e) => {
    e.preventDefault();

    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phonenumber)) {
      alert('Phone number must start with 6, 7, 8, or 9 and be exactly 10 digits.');
      return;
    }

    const userData = { email, password, phonenumber };
    localStorage.setItem(email, JSON.stringify(userData));
    alert('Account created successfully!');
    navigate('/');
  };

  return (
    <div className="register-container">
      <form className="register-form" onSubmit={handleRegister}>
        <h2 className="register-title">Create Your Account</h2>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
          className="register-input"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          required
          className="register-input"
        />
        <input
          type="text"
          placeholder="Phone Number"
          value={phonenumber}
          onChange={e => setPhoneNumber(e.target.value)}
          required
          className="register-input"
        />
        <button type="submit" className="register-btn">Register</button>
        <p className="register-toggle-text">
          Already have an account?{' '}
          <span onClick={() => navigate('/login')} className="register-toggle-link">
            Login
          </span>
        </p>
      </form>
    </div>
  );
}

export default RegisterPage;
