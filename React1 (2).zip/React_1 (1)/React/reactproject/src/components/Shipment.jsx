import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/Shipment.css';

function Shipment() {
  const [shipments, setShipments] = useState([]);
  const [stockItems, setStockItems] = useState([
    { id: 1, name: 'Laptop' },
    { id: 2, name: 'Phone' },
    { id: 3, name: 'Tablet' },
    { id: 4, name: 'Monitor' }
  ]);

  const [form, setForm] = useState({
    itemId: '',
    origin: '',
    destination: '',
    status: '',
    expectedDelivery: ''
  });

  const navigate = useNavigate();

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: name === 'itemId' ? Number(value) : value
    }));
  };

  const receiveShipment = async () => {
    const { itemId, origin, destination, status, expectedDelivery } = form;

    if (!itemId || !origin.trim() || !destination.trim() || !status.trim() || !expectedDelivery) {
      alert('Please fill in all fields');
      return;
    }

    const payload = {
      itemId, // ✅ Now sending as a primitive number
      origin,
      destination,
      status,
      expectedDelivery
    };

    try {
      await axios.post('http://localhost:8080/shipments/received', payload, {
        headers: { 'Content-Type': 'application/json' }
      });

      fetchShipments();
      setForm({ itemId: '', origin: '', destination: '', status: '', expectedDelivery: '' });
    } catch (error) {
      console.error('Error receiving shipment:', error.response?.data || error.message);
    }
  };

  const fetchShipments = async (status) => {
    try {
      const res = await axios.get(`http://localhost:8080/shipments/status/${status}`);
      const data = res.data.map(s => ({
        shipmentId: s.shipmentId,
        itemId: s.itemId,
        origin: s.origin,
        destination: s.destination,
        status: s.status,
        expectedDelivery: s.expectedDelivery
      }));
      setShipments(data);
    } catch (err) {
      console.error('Error fetching shipments:', err);
    }
  };

  const dispatchShipment = async (id) => {
    try {
      await axios.put(`http://localhost:8080/shipments/dispatch/${id}`);
      alert('Shipment dispatched');
      fetchShipments();
    } catch (err) {
      console.error('Dispatch error:', err);
    }
  };

  useEffect(() => {
    fetchShipments();
  }, []);

  return (
    <div className="module-container">
      <div className="shipment-header">
        <h2>Shipment Handling</h2>
        <button className="home-button" onClick={() => navigate('/sidebar')}>🏠 Home</button>
      </div>

      <div className="form-group">
        <input name="itemId" type="number" placeholder="Item ID" value={form.itemId} onChange={handleChange} className="stockitem-select" />
        <input name="origin" placeholder="Origin" value={form.origin} onChange={handleChange} />
        <input name="destination" placeholder="Destination" value={form.destination} onChange={handleChange} />
        <input name="status" placeholder="Status" value={form.status} onChange={handleChange} />
        <input name="expectedDelivery" type="date" value={form.expectedDelivery} onChange={handleChange} />
        <button onClick={receiveShipment}>Receive</button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Item ID</th>
            <th>Origin</th>
            <th>Destination</th>
            <th>Status</th>
            <th>Expected Delivery</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {shipments.map(s => (
            <tr key={s.shipmentId}>
              <td>{s.itemId}</td>
              <td>{s.origin}</td>
              <td>{s.destination}</td>
              <td>{s.status}</td>
              <td>{s.expectedDelivery}</td>
              <td>
                <button onClick={() => dispatchShipment(s.shipmentId)}>Dispatch</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Shipment;
