import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/LoginPage.css';

function LoginPage() {
  const navigate = useNavigate();
  const sliderRef = useRef(null);

  const [isSignup, setIsSignup] = useState(false);
  const [role, setRole] = useState('customer');
  const [form, setForm] = useState({
    username: '',
    password: '',
    mobile: '',
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const validateSignup = () => {
    const newErrors = {};
    if (!/^[6-8]\d{9}$/.test(form.mobile)) {
      newErrors.mobile =
        'Mobile must start with 6-8 and be exactly 10 digits';
    }
    if (
      !/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
        form.password
      )
    ) {
      newErrors.password =
        'Password needs 8+ chars, letters, numbers & special chars';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateLogin = () => {
    const newErrors = {};
    if (!form.username.trim()) newErrors.username = 'Username is required';
    if (!form.password) newErrors.password = 'Password is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (isSignup) {
      if (!validateSignup()) return;

      localStorage.setItem(form.username, JSON.stringify({
        username: form.username,
        password: form.password,
        mobile: form.mobile,
        role
      }));
      alert('Account created successfully!');
      setIsSignup(false);
      setForm({ username: '', password: '', mobile: '' });
      return;
    } else {
      if (!validateLogin()) return;

      const userData = localStorage.getItem(form.username);
      if (!userData) {
        setErrors({ username: 'User not found' });
        return;
      }
      const parsed = JSON.parse(userData);
      if (parsed.password !== form.password) {
        setErrors({ password: 'Incorrect password' });
        return;
      }

      const dest = parsed.role === 'employee' ? '/sidebar' : '/customerHome';
      navigate(dest, { state: { username: form.username } });
    }
  };

  const scroll = (dir) => {
    if (!sliderRef.current) return;
    const { clientWidth } = sliderRef.current;
    sliderRef.current.scrollBy({
      left: dir === 'next' ? clientWidth : -clientWidth,
      behavior: 'smooth',
    });
  };

  return (
    <div className="auth-background">
      <header className="page-header">
        <h1>MyApp Portal</h1>
      </header>

      <div className="login-container">
        <form className="login-form" onSubmit={e => { e.preventDefault(); handleSubmit(); }}>
          <h2 className="login-title">{isSignup ? 'Sign Up' : 'Login'}</h2>
          <div className="role-toggle">
            <label>
              <input type="radio" name="role" value="customer" checked={role === 'customer'} onChange={() => setRole('customer')} /> Customer
            </label>
            <label>
              <input type="radio" name="role" value="employee" checked={role === 'employee'} onChange={() => setRole('employee')} /> Employee
            </label>
          </div>
          <input name="username" placeholder="Username" value={form.username} onChange={handleChange} required className="login-input" />
          {errors.username && <p className="error">{errors.username}</p>}
          <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} required className="login-input" />
          {errors.password && <p className="error">{errors.password}</p>}
          {isSignup && (
            <>
              <input name="mobile" placeholder="Mobile Number" value={form.mobile} onChange={handleChange} required className="login-input" />
              {errors.mobile && <p className="error">{errors.mobile}</p>}
            </>
          )}
          <button type="submit" className="login-btn">{isSignup ? 'Sign Up' : 'Login'}</button>
          <p className="toggle-text">
            {isSignup ? 'Already have an account?' : 'New user?'}{' '}
            <span onClick={() => setIsSignup(!isSignup)} className="toggle-link">{isSignup ? 'Login here' : 'Sign up here'}</span>
          </p>
        </form>
      </div>

      <footer className="page-footer">
        <p>© 2025 MyApp. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default LoginPage;
