import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../styles/Space.css';

function Space() {
  const [spaces, setSpaces] = useState([]);
  const [form, setForm] = useState({ totalCapacity: '', usedCapacity: '', zone: '' });
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:8080/space/view')
      .then(res => {
        if (Array.isArray(res.data)) {
          setSpaces(res.data);
        } else {
          console.error('Unexpected response format:', res.data);
          setSpaces([]);
        }
      })
      .catch(err => {
        console.error('Error fetching spaces:', err);
        setSpaces([]);
      });
  }, []);

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const allocateSpace = () => {
    const total = parseFloat(form.totalCapacity);
    const used = parseFloat(form.usedCapacity);
    const zone = form.zone.trim();

    if (isNaN(total) || total <= 0 || isNaN(used) || used < 0 || !zone) {
      alert("Please enter valid values");
      return;
    }

    const available = total - used;
    const newSpace = { totalCapacity: total, usedCapacity: used, availableCapacity: available, zone };

    axios.post('http://localhost:8080/space/create', newSpace)
      .then(res => {
        const saved = res.data;
        const spaceWithId = { ...saved, spaceId: saved.spaceId || Date.now() };
        setSpaces(prev => [...prev, spaceWithId]);
        setForm({ totalCapacity: '', usedCapacity: '', zone: '' });
      })
      .catch(err => {
        alert('Error creating space');
        console.error('Error creating space:', err);
      });
  };

  return (
    <div className="module-container">
      <div className="space-header">
        <h2>Space Optimization</h2>
        <button className="home-button" onClick={() => navigate('/sidebar')}>🏠 Home</button>
      </div>

      <div className="form-group">
        <input
          name="totalCapacity"
          type="number"
          placeholder="Total Capacity"
          value={form.totalCapacity}
          onChange={handleChange}
        />
        <input
          name="usedCapacity"
          type="number"
          placeholder="Used Capacity"
          value={form.usedCapacity}
          onChange={handleChange}
        />
        <input
          name="zone"
          placeholder="Zone"
          value={form.zone}
          onChange={handleChange}
        />
        <button onClick={allocateSpace}>Allocate</button>
      </div>

      <table>
        <thead>
          <tr><th>Total</th><th>Used</th><th>Available</th><th>Zone</th></tr>
        </thead>
        <tbody>
          {spaces.map(s => (
            <tr key={s.spaceId}>
              <td>{s.totalCapacity}</td>
              <td>{s.usedCapacity}</td>
              <td>{s.availableCapacity}</td>
              <td>{s.zone}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Space;
