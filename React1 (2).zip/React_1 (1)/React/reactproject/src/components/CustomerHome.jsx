import React, { useState } from 'react';
import { Link, useLocation, Navigate } from 'react-router-dom';
import '../styles/CustomerHome.css';

export default function CustomerHome() {
  const { state } = useLocation();
  const username = state?.username || 'Customer';

  // track which footer link is active
  const [activeSection, setActiveSection] = useState('');
  const [redirect, setRedirect] = useState(false);

  if (redirect) {
    return <Navigate to="/customer" replace />;
  }

  return (
    <div className="customer-home" style={{ display: 'flex', minHeight: '100vh' }}>
      {/* SIDEBAR */}
      <aside className="customer-sidebar" style={{ width: '220px', background: '#2f3542', color: '#fff', padding: '32px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', minHeight: '100vh', position: 'fixed', left: 0, top: 0, zIndex: 100 }}>
        <h2 style={{ marginBottom: '40px', fontSize: '1.4rem', fontWeight: 700 }}>Customer Menu</h2>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '24px', width: '100%' }}>
          <Link to="/customer" style={{ color: '#fff', textDecoration: 'none', fontSize: '1.1rem', padding: '12px 0', textAlign: 'center', borderRadius: '6px', transition: 'background 0.2s' }}>My Profile</Link>
          <Link to="/" style={{ color: '#fff', textDecoration: 'none', fontSize: '1.1rem', padding: '12px 0', textAlign: 'center', borderRadius: '6px', transition: 'background 0.2s' }}>Logout</Link>
        </nav>
      </aside>
      <div style={{ marginLeft: '220px', width: '100%' }}>
        <div className="customer-content">
          {/* HEADER */}
          <header className="page-header">
            <h1>Welcome, {username}!</h1>
          </header>

          {/* MAIN */}
          <main className="customer-main">
            <h2>Customer Dashboard</h2>
            <p>
              This is your home page. From here you can access your profile, view
              orders, and manage your account.
            </p>
            <button className="btn" onClick={() => setRedirect(true)}>
              Go to Customer Page
            </button>
          </main>

          {/* SERVICES SECTION */}
          <section className="services-section">
            <h2>Our Services</h2>
            <div className="service-item">
              <div className="service-content">
                <h3>Express Parcel</h3>
                <p>
                  Rapid technical breakthroughs, changing customer expectations and strong government investments in infrastructure are all driving a revolutionary change in India's express logistics and parcel delivery industry. Recent developments indicate that this vibrant sector is not only changing the way commodities are delivered but is also significantly contributing to the expansion of the national economy. The rise of the hyperlocal delivery market, expanding e-commerce industry and increasing disposable incomes have been the key contributors to the boom in this industry.
                </p>
              </div>
            </div>
            <div className="service-item">
              <div className="service-content">
                <h3>Warehousing</h3>
                <p>
                  A warehouse is a commercial building designed for the storage of goods. It serves as a pivotal space where products are kept safe until they are transported to retailers, distributors, or directly to customers. Warehouses are integral to modern supply chain operations, enhancing the utility value of goods and facilitating efficient handling and distribution
                </p>
              </div>
            </div>
          </section>

          {/* SUPPORT SECTION */}
          <section className="info-section">
            <h2>Support</h2>
            <p>
              Our 24/7 support team is here to help with onboarding, troubleshooting, and custom integrations. Chat or email us anytime.
            </p>
          </section>

          {/* LOCATIONS SECTION */}
          <section className="info-section">
            <h2>Our Locations</h2>
            <ol>
              <li>Chennai (Headquarters)</li>
              <li>Bengaluru Warehouse</li>
              <li>Delhi Distribution Center</li>
            </ol>
          </section>

          {/* PROFILE SECTION */}
          {/* Removed customer profile section as requested */}

          {/* DYNAMIC CONTENT */}
          {activeSection && (
            <div className="dynamic-content">
              {activeSection === 'warehousing' && (
                <section>
                  <h2>Warehousing Solutions</h2>
                  <p>
                    Our warehousing services offer secure, scalable storage facilities with climate
                    control, 24/7 monitoring, and real-time inventory tracking. Whether you need bulk
                    storage or just-in-time distribution, we have the capacity and technology to meet
                    your needs.
                  </p>
                </section>
              )}

              {activeSection === 'management' && (
                <section>
                  <h2>Warehouse Management</h2>
                  <p>
                    Our Warehouse Management System (WMS) optimizes every step of your supply chain.
                    From inbound receiving and put-away to outbound shipping, our platform provides
                    actionable insights, automated workflows, and robust reporting to boost efficiency
                    and reduce costs.
                  </p>
                </section>
              )}

              {activeSection === 'support' && (
                <section>
                  <h2>Support</h2>
                  <p>
                    Need help? Our support team is available 24/7 for all your queries—technical,
                    account, or order-related.  
                    Call us: <strong>+91 98765 43210</strong>  
                    Email: <strong>support@myapp.com</strong>
                  </p>
                </section>
              )}
            </div>
          )}

          {/* FOOTER WITH QUICK LINKS */}
          <footer className="page-footer">
            <div className="footer-links">
              <button onClick={() => setActiveSection('warehousing')}>
                Warehousing
              </button>
              <button onClick={() => setActiveSection('management')}>
                Management
              </button>
              <button onClick={() => setActiveSection('support')}>
                Support
              </button>
            </div>
            <p>© 2025 MyApp. All rights reserved.</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
