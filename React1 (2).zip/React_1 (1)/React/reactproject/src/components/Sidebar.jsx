import React from 'react';
import { Link } from 'react-router-dom';
import warehouseImg from '../styles/image.jpg';

function Sidebar() {
  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', position: 'relative' }}>
      <div className="sidebar" style={{ width: '220px', background: '#2f3542', color: '#fff', padding: '32px 0', position: 'relative', zIndex: 2, left: '40px' }}>
        <h2 style={{ marginLeft: '20px' }}>LWMS</h2>
        <ul style={{ marginLeft: '20px' }}>
          <li><Link to="/inventory">Inventory</Link></li>
          <li><Link to="/space">Space</Link></li>
          <li><Link to="/shipment">Shipment</Link></li>
          <li><Link to="/maintenance">Maintenance</Link></li>
          <li><Link to="/reports">Reports</Link></li>
        </ul>
      </div>
      <img src={warehouseImg} alt="Warehouse" style={{ position: 'absolute', left: 220, top: 0, width: 'calc(100vw - 220px)', height: '100vh', objectFit: 'cover', zIndex: 1 }} />
    </div>
  );
}

export default Sidebar;
