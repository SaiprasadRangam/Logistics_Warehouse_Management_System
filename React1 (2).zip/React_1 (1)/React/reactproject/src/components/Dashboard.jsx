import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Dashboard.css';

function Dashboard() {
 
  const stats = [
    { label: 'Total Shipments', icon: '🚚' },
    { label: 'Inventory Accuracy', icon: '📦' },
    { label: 'Warehouse Utilization',  icon: '🏢' },
    { label: 'Avg. Maintenance Time',  icon: '🛠️' },
    { label: 'Reports Generated', icon: '📈' }
  ];
  const navigate = useNavigate();
  const location = window.location;
  let email = '';
  if (location && location.state && location.state.email) {
    email = location.state.email;
  } else if (window.history && window.history.state && window.history.state.usr && window.history.state.usr.email) {
    email = window.history.state.usr.email;
  }

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="logo">SmartOps LWMS</div>
        {email && (
          <div style={{ color: '#0077cc', fontWeight: 600, fontSize: '1.1rem', marginLeft: '20px' }}>
            Welcome, {email}!
          </div>
        )}
        <nav className="nav-bar">
          <button
            className="nav-button"
            onClick={() => navigate('/login')}
          >
            <span className="nav-label">Login</span>
          </button>
          <button
            className="nav-button"
            onClick={() => navigate('/register')}
          >
            <span className="nav-label">Sign Up</span>
          </button>
        </nav>
      </header>
      <section className="about-section">
       
        <p>
          Smart Ops is a cutting-edge Warehouse Management System (WMS) designed to optimize your supply chain with real-time visibility and streamlined order fulfillment.
        </p>
      </section>
      <section className="stats-container white-bg">
        <h3>📊 Application Statistics</h3>
        <div className="stats-grid">
          {stats.map(stat => (
            <div key={stat.label} className="stat-card">
              <span className="stat-icon">{stat.icon}</span>
              <h4>{stat.label}</h4>
              <p>{stat.value}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="services-section">
        <h2>Our Services</h2>
        <div className="service-item">
          <div className="service-content">
            <h3>Express Parcel</h3>
            <p>
              Rapid technical breakthroughs, changing customer expectations and strong government investments in infrastructure are all driving a revolutionary change in India's express logistics and parcel delivery industry. Recent developments indicate that this vibrant sector is not only changing the way commodities are delivered but is also significantly contributing to the expansion of the national economy. The rise of the hyperlocal delivery market, expanding e-commerce industry and increasing disposable incomes have been the key contributors to the boom in this industry.
            </p>
          </div>
        </div>
        <div className="service-item">
          <div className="service-content">
            <h3>Warehousing</h3>
            <p>
              A warehouse is a commercial building designed for the storage of goods. It serves as a pivotal space where products are kept safe until they are transported to retailers, distributors, or directly to customers. Warehouses are integral to modern supply chain operations, enhancing the utility value of goods and facilitating efficient handling and distribution
            </p>
          </div>
        </div>
      </section>
      <section className="info-section">
        <h2>Support</h2>
        <p>
          Our 24/7 support team is here to help with onboarding, troubleshooting, and custom integrations. Chat or email us anytime.
        </p>
      </section>
      <section className="info-section">
        <h2>Our Locations</h2>
        <ol>
          <p>Chennai (Headquarters)</p>
          <p>Bengaluru Warehouse</p>
          <p>Delhi Distribution Center</p>
        </ol>
      </section>
      <section className="about-cards-section">
        <div className="about-cards">
          <div className="about-card transparent">
            <span className="card-icon">🚀</span>
            <h3>D2C Brands</h3>
            <p>Empowering direct-to-consumer businesses with a seamless logistics ecosystem. Our integrated services—Express Parcel, Cross Border, Warehousing, Freight, and smart software solutions—enable faster deliveries and elevate customer experience.</p>
          </div>
          <div className="about-card transparent">
            <span className="card-icon">📦</span>
            <h3>Personal Courier</h3>
            <p>India’s first and only online courier platform tailored for personal shipments. Send packages nationwide or internationally with ease—enjoy free doorstep pickup, real-time tracking, and a hassle-free experience through our app.</p>
          </div>
          <div className="about-card transparent">
            <span className="card-icon">🏭</span>
            <h3>B2B Enterprises</h3>
            <p>End-to-end logistics solutions designed for enterprise supply chains. From factory to retail, our customized approach combines warehousing, advanced technology, and a robust delivery network to boost reliability and cut costs.</p>
          </div>
        </div>
      </section>
      <footer className="dashboard-footer">
        <p>&copy; {new Date().getFullYear()} SmartOps Inc. | All rights reserved</p>
      </footer>
    </div>
  );
}

export default Dashboard;

