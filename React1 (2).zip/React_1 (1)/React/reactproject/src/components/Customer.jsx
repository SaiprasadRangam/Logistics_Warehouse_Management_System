import React from 'react';
import '../styles/Customer.css';

const inventoryItems = [
  { id: 'ITM001', name: 'Laptop', quantity: 10, location: 'Zone A' },
  { id: 'ITM002', name: 'Monitor', quantity: 5, location: 'Zone B' },
  { id: 'ITM003', name: 'Keyboard', quantity: 20, location: 'Zone C' },
  { id: 'ITM004', name: 'Mouse', quantity: 15, location: 'Zone A' },
];

function Customer() {
  return (
    <div className="customer-inventory-container">
      <h2>My Inventory Items</h2>
      <table className="customer-inventory-table">
        <thead>
          <tr>
            <th>Item ID</th>
            <th>Name</th>
            <th>Quantity</th>
            <th>Location</th>
          </tr>
        </thead>
        <tbody>
          {inventoryItems.map(item => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.quantity}</td>
              <td>{item.location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Customer;