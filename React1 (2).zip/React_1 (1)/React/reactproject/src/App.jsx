import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';


import Dashboard from './components/Dashboard';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import Sidebar from './components/Sidebar';
import Inventory from './components/Inventory';
import Space from './components/Space';
import Shipment from './components/Shipment';
import Maintenance from './components/Maintenance';
import Reports from './components/Reports';
import Customer from './components/Customer';
import CustomerHome from './components/CustomerHome';

function App() {
  return (
    <Router>
      <div className="app-container">
        
        <div className="main-content">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/" element={<Dashboard />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/sidebar" element={<Sidebar />} /> 
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/space" element={<Space />} />
            <Route path="/shipment" element={<Shipment />} />
            <Route path="/maintenance" element={<Maintenance />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/customer" element={<Customer />} />
            <Route path="/customerHome" element={<CustomerHome />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;