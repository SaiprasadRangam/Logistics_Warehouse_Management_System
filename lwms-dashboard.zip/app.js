const { useState, useEffect, useRef } = React;

// Initial data
const initialData = {
  inventory: [
    {
      itemId: 1,
      itemName: "Laptop Dell XPS 13",
      category: "Electronics",
      quantity: 25,
      location: "Zone A-1",
      lastUpdated: "2025-08-20T10:30:00Z"
    },
    {
      itemId: 2,
      itemName: "Office Chair Ergonomic",
      category: "Furniture",
      quantity: 50,
      location: "Zone B-2",
      lastUpdated: "2025-08-19T14:20:00Z"
    },
    {
      itemId: 3,
      itemName: "Wireless Mouse",
      category: "Electronics",
      quantity: 150,
      location: "Zone A-3",
      lastUpdated: "2025-08-21T09:15:00Z"
    },
    {
      itemId: 4,
      itemName: "Steel Filing Cabinet",
      category: "Furniture",
      quantity: 8,
      location: "Zone C-1",
      lastUpdated: "2025-08-18T16:45:00Z"
    },
    {
      itemId: 5,
      itemName: "Printer HP LaserJet",
      category: "Electronics",
      quantity: 12,
      location: "Zone A-2",
      lastUpdated: "2025-08-22T11:30:00Z"
    }
  ],
  spaces: [
    {
      spaceId: 1,
      zone: "Zone A",
      totalCapacity: 1000,
      usedCapacity: 750,
      availableCapacity: 250
    },
    {
      spaceId: 2,
      zone: "Zone B",
      totalCapacity: 800,
      usedCapacity: 600,
      availableCapacity: 200
    },
    {
      spaceId: 3,
      zone: "Zone C",
      totalCapacity: 500,
      usedCapacity: 300,
      availableCapacity: 200
    },
    {
      spaceId: 4,
      zone: "Zone D",
      totalCapacity: 1200,
      usedCapacity: 900,
      availableCapacity: 300
    }
  ],
  shipments: [
    {
      shipmentId: 1,
      itemId: 1,
      origin: "Supplier A",
      destination: "Customer B",
      status: "In Transit",
      expectedDeliveryDate: "2025-08-28T00:00:00Z"
    },
    {
      shipmentId: 2,
      itemId: 3,
      origin: "Warehouse Main",
      destination: "Branch Office",
      status: "Delivered",
      expectedDeliveryDate: "2025-08-25T00:00:00Z"
    },
    {
      shipmentId: 3,
      itemId: 2,
      origin: "Manufacturing Unit",
      destination: "Warehouse Main",
      status: "Pending",
      expectedDeliveryDate: "2025-08-30T00:00:00Z"
    },
    {
      shipmentId: 4,
      itemId: 5,
      origin: "Supplier C",
      destination: "Customer D",
      status: "In Transit",
      expectedDeliveryDate: "2025-08-27T00:00:00Z"
    }
  ],
  maintenanceSchedule: [
    {
      scheduleId: 1,
      equipmentId: 101,
      taskDescription: "Forklift hydraulic system check",
      scheduledDate: "2025-08-30T09:00:00Z",
      completionStatus: "Pending"
    },
    {
      scheduleId: 2,
      equipmentId: 102,
      taskDescription: "Conveyor belt maintenance",
      scheduledDate: "2025-08-28T14:00:00Z",
      completionStatus: "Completed"
    },
    {
      scheduleId: 3,
      equipmentId: 103,
      taskDescription: "HVAC system filter replacement",
      scheduledDate: "2025-09-01T10:30:00Z",
      completionStatus: "Pending"
    },
    {
      scheduleId: 4,
      equipmentId: 104,
      taskDescription: "Loading dock door repair",
      scheduledDate: "2025-08-29T08:00:00Z",
      completionStatus: "In Progress"
    }
  ],
  reports: [
    {
      reportId: 1,
      reportType: "Inventory Turnover",
      generatedOn: "2025-08-26T12:00:00Z",
      details: "Monthly inventory turnover analysis showing 15% improvement"
    },
    {
      reportId: 2,
      reportType: "Space Utilization",
      generatedOn: "2025-08-25T15:30:00Z",
      details: "Current space utilization at 78% capacity across all zones"
    },
    {
      reportId: 3,
      reportType: "Shipment Performance",
      generatedOn: "2025-08-24T11:45:00Z",
      details: "Average delivery time reduced by 20% compared to last month"
    }
  ],
  dashboardMetrics: {
    totalItems: 245,
    activeShipments: 8,
    spaceUtilization: 78,
    pendingMaintenance: 2,
    lowStockItems: 3,
    overdueShipments: 1
  }
};

// Utility functions
const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const getStatusBadgeClass = (status) => {
  const statusLower = status.toLowerCase().replace(' ', '-');
  return `status-badge--${statusLower}`;
};

// Modal Component
const Modal = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className="modal" onClick={onClose}>
      <div className="modal__content" onClick={(e) => e.stopPropagation()}>
        <div className="modal__header">
          <h3 className="modal__title">{title}</h3>
          <button className="modal__close" onClick={onClose}>
            <i className="fas fa-times"></i>
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

// Alert Component
const Alert = ({ type, message, onClose }) => {
  useEffect(() => {
    if (onClose) {
      const timer = setTimeout(onClose, 3000);
      return () => clearTimeout(timer);
    }
  }, [onClose]);

  return (
    <div className={`alert alert--${type}`}>
      <i className={`fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}`}></i>
      {message}
    </div>
  );
};

// Dashboard Component
const Dashboard = ({ data }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');
      
      // Destroy existing chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      chartInstance.current = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: data.spaces.map(space => space.zone),
          datasets: [{
            data: data.spaces.map(space => space.usedCapacity),
            backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5'],
            borderWidth: 2,
            borderColor: '#fff'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                padding: 20,
                usePointStyle: true
              }
            }
          }
        }
      });
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data.spaces]);

  const recentActivities = [
    {
      id: 1,
      title: 'New inventory item added',
      description: 'Laptop Dell XPS 13 added to Zone A-1',
      time: '2 hours ago',
      icon: 'fa-plus',
      type: 'success'
    },
    {
      id: 2,
      title: 'Shipment dispatched',
      description: 'Shipment #1001 sent to Customer B',
      time: '4 hours ago',
      icon: 'fa-truck',
      type: 'info'
    },
    {
      id: 3,
      title: 'Maintenance completed',
      description: 'Conveyor belt maintenance finished',
      time: '6 hours ago',
      icon: 'fa-wrench',
      type: 'success'
    },
    {
      id: 4,
      title: 'Low stock alert',
      description: 'Steel Filing Cabinet below minimum',
      time: '1 day ago',
      icon: 'fa-exclamation-triangle',
      type: 'warning'
    }
  ];

  return (
    <div>
      <div className="header">
        <div className="header__title">
          <h1>Dashboard</h1>
          <p>Welcome back! Here's what's happening in your warehouse today.</p>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="metric-card">
          <div className="metric-card__header">
            <span className="metric-card__title">Total Items</span>
            <div className="metric-card__icon metric-card__icon--primary">
              <i className="fas fa-boxes"></i>
            </div>
          </div>
          <p className="metric-card__value">{data.dashboardMetrics.totalItems}</p>
          <p className="metric-card__change metric-card__change--positive">
            <i className="fas fa-arrow-up"></i> 5% from last month
          </p>
        </div>

        <div className="metric-card">
          <div className="metric-card__header">
            <span className="metric-card__title">Active Shipments</span>
            <div className="metric-card__icon metric-card__icon--success">
              <i className="fas fa-truck"></i>
            </div>
          </div>
          <p className="metric-card__value">{data.dashboardMetrics.activeShipments}</p>
          <p className="metric-card__change metric-card__change--positive">
            <i className="fas fa-arrow-up"></i> 12% from last week
          </p>
        </div>

        <div className="metric-card">
          <div className="metric-card__header">
            <span className="metric-card__title">Space Utilization</span>
            <div className="metric-card__icon metric-card__icon--warning">
              <i className="fas fa-warehouse"></i>
            </div>
          </div>
          <p className="metric-card__value">{data.dashboardMetrics.spaceUtilization}%</p>
          <p className="metric-card__change metric-card__change--positive">
            <i className="fas fa-arrow-up"></i> 3% from last month
          </p>
        </div>

        <div className="metric-card">
          <div className="metric-card__header">
            <span className="metric-card__title">Pending Maintenance</span>
            <div className="metric-card__icon metric-card__icon--error">
              <i className="fas fa-wrench"></i>
            </div>
          </div>
          <p className="metric-card__value">{data.dashboardMetrics.pendingMaintenance}</p>
          <p className="metric-card__change metric-card__change--negative">
            <i className="fas fa-arrow-down"></i> 1 from yesterday
          </p>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="content-section">
          <div className="content-section__header">
            <h3 className="content-section__title">Space Utilization Overview</h3>
          </div>
          <div className="content-section__body">
            <div className="chart-container" style={{position: 'relative', height: '300px'}}>
              <canvas ref={chartRef}></canvas>
            </div>
          </div>
        </div>

        <div className="content-section">
          <div className="content-section__header">
            <h3 className="content-section__title">Recent Activities</h3>
          </div>
          <div className="content-section__body">
            <ul className="activity-list">
              {recentActivities.map(activity => (
                <li key={activity.id} className="activity-item">
                  <div className={`activity-icon metric-card__icon--${activity.type}`}>
                    <i className={`fas ${activity.icon}`}></i>
                  </div>
                  <div className="activity-content">
                    <div className="activity-title">{activity.title}</div>
                    <div className="activity-description">{activity.description}</div>
                    <div className="activity-time">{activity.time}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

// Inventory Management Component
const InventoryManagement = ({ data, onUpdateData }) => {
  const [inventory, setInventory] = useState(data.inventory);
  const [filteredInventory, setFilteredInventory] = useState(data.inventory);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [alert, setAlert] = useState(null);

  const [formData, setFormData] = useState({
    itemName: '',
    category: '',
    quantity: '',
    location: ''
  });

  useEffect(() => {
    let filtered = inventory;

    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.location.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter) {
      filtered = filtered.filter(item => item.category === categoryFilter);
    }

    setFilteredInventory(filtered);
  }, [inventory, searchTerm, categoryFilter]);

  const categories = [...new Set(inventory.map(item => item.category))];

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingItem) {
      const updatedInventory = inventory.map(item =>
        item.itemId === editingItem.itemId
          ? { ...item, ...formData, lastUpdated: new Date().toISOString() }
          : item
      );
      setInventory(updatedInventory);
      onUpdateData({ ...data, inventory: updatedInventory });
      setAlert({ type: 'success', message: 'Item updated successfully!' });
    } else {
      const newItem = {
        itemId: Math.max(...inventory.map(item => item.itemId)) + 1,
        ...formData,
        quantity: parseInt(formData.quantity),
        lastUpdated: new Date().toISOString()
      };
      const updatedInventory = [...inventory, newItem];
      setInventory(updatedInventory);
      onUpdateData({ ...data, inventory: updatedInventory });
      setAlert({ type: 'success', message: 'Item added successfully!' });
    }

    setShowModal(false);
    setEditingItem(null);
    setFormData({ itemName: '', category: '', quantity: '', location: '' });
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      itemName: item.itemName,
      category: item.category,
      quantity: item.quantity.toString(),
      location: item.location
    });
    setShowModal(true);
  };

  const handleDelete = (itemId) => {
    if (confirm('Are you sure you want to delete this item?')) {
      const updatedInventory = inventory.filter(item => item.itemId !== itemId);
      setInventory(updatedInventory);
      onUpdateData({ ...data, inventory: updatedInventory });
      setAlert({ type: 'success', message: 'Item deleted successfully!' });
    }
  };

  const resetForm = () => {
    setFormData({ itemName: '', category: '', quantity: '', location: '' });
    setEditingItem(null);
    setShowModal(false);
  };

  return (
    <div>
      <div className="header">
        <div className="header__title">
          <h1>Inventory Management</h1>
          <p>Manage your warehouse inventory items, track stock levels, and organize by location.</p>
        </div>
      </div>

      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          onClose={() => setAlert(null)} 
        />
      )}

      <div className="search-filter-bar">
        <div className="search-input">
          <i className="fas fa-search"></i>
          <input
            type="text"
            className="form-control"
            placeholder="Search by item name or location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select
          className="form-control"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          <option value="">All Categories</option>
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>
        <button className="btn btn--primary" onClick={() => setShowModal(true)}>
          <i className="fas fa-plus"></i> Add Item
        </button>
      </div>

      <div className="content-section">
        <div className="content-section__header">
          <h3 className="content-section__title">Inventory Items ({filteredInventory.length})</h3>
        </div>
        <div className="content-section__body">
          {filteredInventory.length > 0 ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Item ID</th>
                  <th>Item Name</th>
                  <th>Category</th>
                  <th>Quantity</th>
                  <th>Location</th>
                  <th>Last Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredInventory.map(item => (
                  <tr key={item.itemId}>
                    <td>#{item.itemId}</td>
                    <td className="font-medium">{item.itemName}</td>
                    <td>
                      <span className="status-badge status-badge--pending">
                        {item.category}
                      </span>
                    </td>
                    <td>
                      <span className={item.quantity < 10 ? 'text-error font-medium' : ''}>
                        {item.quantity}
                        {item.quantity < 10 && <i className="fas fa-exclamation-triangle" style={{marginLeft: '5px'}}></i>}
                      </span>
                    </td>
                    <td>{item.location}</td>
                    <td>{formatDate(item.lastUpdated)}</td>
                    <td>
                      <div className="data-table__actions">
                        <button
                          className="btn btn--sm btn--outline"
                          onClick={() => handleEdit(item)}
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button
                          className="btn btn--sm btn--outline text-error"
                          onClick={() => handleDelete(item.itemId)}
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="empty-state">
              <i className="fas fa-boxes"></i>
              <h3>No items found</h3>
              <p>No inventory items match your search criteria.</p>
            </div>
          )}
        </div>
      </div>

      <Modal
        isOpen={showModal}
        onClose={resetForm}
        title={editingItem ? 'Edit Inventory Item' : 'Add New Inventory Item'}
      >
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Item Name</label>
            <input
              type="text"
              className="form-control"
              required
              value={formData.itemName}
              onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
              placeholder="Enter item name"
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Category</label>
              <select
                className="form-control"
                required
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              >
                <option value="">Select Category</option>
                <option value="Electronics">Electronics</option>
                <option value="Furniture">Furniture</option>
                <option value="Office Supplies">Office Supplies</option>
                <option value="Equipment">Equipment</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Quantity</label>
              <input
                type="number"
                className="form-control"
                required
                min="0"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                placeholder="0"
              />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Location</label>
            <input
              type="text"
              className="form-control"
              required
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              placeholder="e.g., Zone A-1"
            />
          </div>
          <div className="form-actions">
            <button type="button" className="btn btn--outline" onClick={resetForm}>
              Cancel
            </button>
            <button type="submit" className="btn btn--primary">
              <i className="fas fa-save"></i> {editingItem ? 'Update' : 'Add'} Item
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

// Space Optimization Component
const SpaceOptimization = ({ data, onUpdateData }) => {
  const [spaces, setSpaces] = useState(data.spaces);
  const [alert, setAlert] = useState(null);

  const getUtilizationColor = (percentage) => {
    if (percentage >= 90) return 'progress-bar__fill--error';
    if (percentage >= 75) return 'progress-bar__fill--warning';
    return '';
  };

  const getUtilizationStatus = (percentage) => {
    if (percentage >= 90) return 'Critical';
    if (percentage >= 75) return 'High';
    if (percentage >= 50) return 'Medium';
    return 'Low';
  };

  const handleAllocateSpace = (spaceId, amount) => {
    const updatedSpaces = spaces.map(space => {
      if (space.spaceId === spaceId && space.availableCapacity >= amount) {
        return {
          ...space,
          usedCapacity: space.usedCapacity + amount,
          availableCapacity: space.availableCapacity - amount
        };
      }
      return space;
    });
    
    setSpaces(updatedSpaces);
    onUpdateData({ ...data, spaces: updatedSpaces });
    setAlert({ type: 'success', message: `Space allocated successfully!` });
  };

  const handleFreeSpace = (spaceId, amount) => {
    const updatedSpaces = spaces.map(space => {
      if (space.spaceId === spaceId && space.usedCapacity >= amount) {
        return {
          ...space,
          usedCapacity: space.usedCapacity - amount,
          availableCapacity: space.availableCapacity + amount
        };
      }
      return space;
    });
    
    setSpaces(updatedSpaces);
    onUpdateData({ ...data, spaces: updatedSpaces });
    setAlert({ type: 'success', message: `Space freed successfully!` });
  };

  return (
    <div>
      <div className="header">
        <div className="header__title">
          <h1>Space Optimization</h1>
          <p>Monitor warehouse space utilization and optimize storage allocation across zones.</p>
        </div>
      </div>

      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          onClose={() => setAlert(null)} 
        />
      )}

      <div className="space-grid">
        {spaces.map(space => {
          const utilizationPercentage = Math.round((space.usedCapacity / space.totalCapacity) * 100);
          return (
            <div key={space.spaceId} className="space-card">
              <div className="space-card__header">
                <div className="space-card__zone">{space.zone}</div>
                <div className={`status-badge ${
                  utilizationPercentage >= 90 ? 'status-badge--overdue' :
                  utilizationPercentage >= 75 ? 'status-badge--pending' :
                  'status-badge--completed'
                }`}>
                  {getUtilizationStatus(utilizationPercentage)}
                </div>
              </div>
              <div className="space-card__utilization">
                Utilization: {utilizationPercentage}%
              </div>
              <div className="progress-bar">
                <div 
                  className={`progress-bar__fill ${getUtilizationColor(utilizationPercentage)}`}
                  style={{width: `${utilizationPercentage}%`}}
                ></div>
              </div>
              <div className="space-card__details">
                <div>Used: {space.usedCapacity}</div>
                <div>Available: {space.availableCapacity}</div>
                <div>Total: {space.totalCapacity}</div>
              </div>
              <div className="form-actions">
                <button 
                  className="btn btn--sm btn--primary"
                  onClick={() => handleAllocateSpace(space.spaceId, 50)}
                  disabled={space.availableCapacity < 50}
                >
                  <i className="fas fa-plus"></i> Allocate 50
                </button>
                <button 
                  className="btn btn--sm btn--outline"
                  onClick={() => handleFreeSpace(space.spaceId, 50)}
                  disabled={space.usedCapacity < 50}
                >
                  <i className="fas fa-minus"></i> Free 50
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="content-section">
        <div className="content-section__header">
          <h3 className="content-section__title">Space Management Summary</h3>
        </div>
        <div className="content-section__body">
          <table className="data-table">
            <thead>
              <tr>
                <th>Zone</th>
                <th>Total Capacity</th>
                <th>Used Capacity</th>
                <th>Available Capacity</th>
                <th>Utilization %</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {spaces.map(space => {
                const utilizationPercentage = Math.round((space.usedCapacity / space.totalCapacity) * 100);
                return (
                  <tr key={space.spaceId}>
                    <td className="font-medium">{space.zone}</td>
                    <td>{space.totalCapacity.toLocaleString()}</td>
                    <td>{space.usedCapacity.toLocaleString()}</td>
                    <td>{space.availableCapacity.toLocaleString()}</td>
                    <td>
                      <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                        {utilizationPercentage}%
                        <div className="progress-bar" style={{width: '60px', height: '4px'}}>
                          <div 
                            className={`progress-bar__fill ${getUtilizationColor(utilizationPercentage)}`}
                            style={{width: `${utilizationPercentage}%`}}
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className={`status-badge ${
                        utilizationPercentage >= 90 ? 'status-badge--overdue' :
                        utilizationPercentage >= 75 ? 'status-badge--pending' :
                        'status-badge--completed'
                      }`}>
                        {getUtilizationStatus(utilizationPercentage)}
                      </span>
                    </td>
                    <td>
                      <div className="data-table__actions">
                        <button 
                          className="btn btn--sm btn--primary"
                          onClick={() => handleAllocateSpace(space.spaceId, 100)}
                          disabled={space.availableCapacity < 100}
                          title="Allocate 100 units"
                        >
                          <i className="fas fa-plus"></i>
                        </button>
                        <button 
                          className="btn btn--sm btn--outline"
                          onClick={() => handleFreeSpace(space.spaceId, 100)}
                          disabled={space.usedCapacity < 100}
                          title="Free 100 units"
                        >
                          <i className="fas fa-minus"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Shipment Handling Component
const ShipmentHandling = ({ data, onUpdateData }) => {
  const [shipments, setShipments] = useState(data.shipments);
  const [filteredShipments, setFilteredShipments] = useState(data.shipments);
  const [statusFilter, setStatusFilter] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [alert, setAlert] = useState(null);
  
  const [formData, setFormData] = useState({
    itemId: '',
    origin: '',
    destination: '',
    expectedDeliveryDate: ''
  });

  useEffect(() => {
    let filtered = shipments;
    
    if (statusFilter) {
      filtered = filtered.filter(shipment => shipment.status === statusFilter);
    }
    
    setFilteredShipments(filtered);
  }, [shipments, statusFilter]);

  const statuses = ['Pending', 'In Transit', 'Delivered'];
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newShipment = {
      shipmentId: Math.max(...shipments.map(s => s.shipmentId)) + 1,
      ...formData,
      itemId: parseInt(formData.itemId),
      status: 'Pending'
    };
    
    const updatedShipments = [...shipments, newShipment];
    setShipments(updatedShipments);
    onUpdateData({ ...data, shipments: updatedShipments });
    setAlert({ type: 'success', message: 'Shipment created successfully!' });
    
    setShowModal(false);
    setFormData({ itemId: '', origin: '', destination: '', expectedDeliveryDate: '' });
  };

  const handleStatusUpdate = (shipmentId, newStatus) => {
    const updatedShipments = shipments.map(shipment =>
      shipment.shipmentId === shipmentId
        ? { ...shipment, status: newStatus }
        : shipment
    );
    
    setShipments(updatedShipments);
    onUpdateData({ ...data, shipments: updatedShipments });
    setAlert({ type: 'success', message: 'Shipment status updated successfully!' });
  };

  const getItemName = (itemId) => {
    const item = data.inventory.find(item => item.itemId === itemId);
    return item ? item.itemName : `Item #${itemId}`;
  };

  return (
    <div>
      <div className="header">
        <div className="header__title">
          <h1>Shipment Handling</h1>
          <p>Track and manage inbound and outbound shipments with real-time status updates.</p>
        </div>
      </div>

      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          onClose={() => setAlert(null)} 
        />
      )}

      <div className="search-filter-bar">
        <select
          className="form-control"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">All Statuses</option>
          {statuses.map(status => (
            <option key={status} value={status}>{status}</option>
          ))}
        </select>
        <button className="btn btn--primary" onClick={() => setShowModal(true)}>
          <i className="fas fa-plus"></i> New Shipment
        </button>
      </div>

      <div className="content-section">
        <div className="content-section__header">
          <h3 className="content-section__title">Shipments ({filteredShipments.length})</h3>
        </div>
        <div className="content-section__body">
          {filteredShipments.length > 0 ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Shipment ID</th>
                  <th>Item</th>
                  <th>Origin</th>
                  <th>Destination</th>
                  <th>Status</th>
                  <th>Expected Delivery</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredShipments.map(shipment => (
                  <tr key={shipment.shipmentId}>
                    <td>#{shipment.shipmentId}</td>
                    <td className="font-medium">{getItemName(shipment.itemId)}</td>
                    <td>{shipment.origin}</td>
                    <td>{shipment.destination}</td>
                    <td>
                      <span className={`status-badge ${getStatusBadgeClass(shipment.status)}`}>
                        {shipment.status}
                      </span>
                    </td>
                    <td>{formatDate(shipment.expectedDeliveryDate)}</td>
                    <td>
                      <div className="data-table__actions">
                        <select
                          className="form-control"
                          value={shipment.status}
                          onChange={(e) => handleStatusUpdate(shipment.shipmentId, e.target.value)}
                          style={{ minWidth: '120px', fontSize: '12px', padding: '4px 8px' }}
                        >
                          {statuses.map(status => (
                            <option key={status} value={status}>{status}</option>
                          ))}
                        </select>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="empty-state">
              <i className="fas fa-truck"></i>
              <h3>No shipments found</h3>
              <p>No shipments match your filter criteria.</p>
            </div>
          )}
        </div>
      </div>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Create New Shipment"
      >
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Item</label>
            <select
              className="form-control"
              required
              value={formData.itemId}
              onChange={(e) => setFormData({ ...formData, itemId: e.target.value })}
            >
              <option value="">Select Item</option>
              {data.inventory.map(item => (
                <option key={item.itemId} value={item.itemId}>
                  {item.itemName} (ID: {item.itemId})
                </option>
              ))}
            </select>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Origin</label>
              <input
                type="text"
                className="form-control"
                required
                value={formData.origin}
                onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                placeholder="e.g., Warehouse Main"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Destination</label>
              <input
                type="text"
                className="form-control"
                required
                value={formData.destination}
                onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                placeholder="e.g., Customer Location"
              />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Expected Delivery Date</label>
            <input
              type="datetime-local"
              className="form-control"
              required
              value={formData.expectedDeliveryDate}
              onChange={(e) => setFormData({ ...formData, expectedDeliveryDate: e.target.value })}
            />
          </div>
          <div className="form-actions">
            <button type="button" className="btn btn--outline" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn--primary">
              <i className="fas fa-save"></i> Create Shipment
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

// Maintenance Scheduling Component
const MaintenanceScheduling = ({ data, onUpdateData }) => {
  const [maintenance, setMaintenance] = useState(data.maintenanceSchedule);
  const [showModal, setShowModal] = useState(false);
  const [alert, setAlert] = useState(null);
  
  const [formData, setFormData] = useState({
    equipmentId: '',
    taskDescription: '',
    scheduledDate: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newTask = {
      scheduleId: Math.max(...maintenance.map(m => m.scheduleId)) + 1,
      ...formData,
      equipmentId: parseInt(formData.equipmentId),
      completionStatus: 'Pending'
    };
    
    const updatedMaintenance = [...maintenance, newTask];
    setMaintenance(updatedMaintenance);
    onUpdateData({ ...data, maintenanceSchedule: updatedMaintenance });
    setAlert({ type: 'success', message: 'Maintenance task scheduled successfully!' });
    
    setShowModal(false);
    setFormData({ equipmentId: '', taskDescription: '', scheduledDate: '' });
  };

  const handleStatusUpdate = (scheduleId, newStatus) => {
    const updatedMaintenance = maintenance.map(task =>
      task.scheduleId === scheduleId
        ? { ...task, completionStatus: newStatus }
        : task
    );
    
    setMaintenance(updatedMaintenance);
    onUpdateData({ ...data, maintenanceSchedule: updatedMaintenance });
    setAlert({ type: 'success', message: 'Maintenance status updated successfully!' });
  };

  const isOverdue = (scheduledDate, status) => {
    return status === 'Pending' && new Date(scheduledDate) < new Date();
  };

  const statuses = ['Pending', 'In Progress', 'Completed'];

  return (
    <div>
      <div className="header">
        <div className="header__title">
          <h1>Maintenance Scheduling</h1>
          <p>Schedule and track maintenance activities for warehouse equipment and infrastructure.</p>
        </div>
      </div>

      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          onClose={() => setAlert(null)} 
        />
      )}

      <div className="search-filter-bar">
        <button className="btn btn--primary" onClick={() => setShowModal(true)}>
          <i className="fas fa-plus"></i> Schedule Maintenance
        </button>
      </div>

      <div className="content-section">
        <div className="content-section__header">
          <h3 className="content-section__title">Maintenance Schedule</h3>
        </div>
        <div className="content-section__body">
          <table className="data-table">
            <thead>
              <tr>
                <th>Schedule ID</th>
                <th>Equipment ID</th>
                <th>Task Description</th>
                <th>Scheduled Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {maintenance.map(task => {
                const overdue = isOverdue(task.scheduledDate, task.completionStatus);
                return (
                  <tr key={task.scheduleId}>
                    <td>#{task.scheduleId}</td>
                    <td>EQ-{task.equipmentId}</td>
                    <td className="font-medium">{task.taskDescription}</td>
                    <td>
                      {formatDate(task.scheduledDate)}
                      {overdue && (
                        <div className="status-badge status-badge--overdue" style={{marginTop: '4px'}}>
                          Overdue
                        </div>
                      )}
                    </td>
                    <td>
                      <span className={`status-badge ${getStatusBadgeClass(task.completionStatus)}`}>
                        {task.completionStatus}
                      </span>
                    </td>
                    <td>
                      <div className="data-table__actions">
                        <select
                          className="form-control"
                          value={task.completionStatus}
                          onChange={(e) => handleStatusUpdate(task.scheduleId, e.target.value)}
                          style={{ minWidth: '120px', fontSize: '12px', padding: '4px 8px' }}
                        >
                          {statuses.map(status => (
                            <option key={status} value={status}>{status}</option>
                          ))}
                        </select>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Schedule Maintenance Task"
      >
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Equipment ID</label>
            <input
              type="number"
              className="form-control"
              required
              value={formData.equipmentId}
              onChange={(e) => setFormData({ ...formData, equipmentId: e.target.value })}
              placeholder="e.g., 105"
            />
          </div>
          <div className="form-group">
            <label className="form-label">Task Description</label>
            <textarea
              className="form-control"
              required
              rows="3"
              value={formData.taskDescription}
              onChange={(e) => setFormData({ ...formData, taskDescription: e.target.value })}
              placeholder="Describe the maintenance task..."
            />
          </div>
          <div className="form-group">
            <label className="form-label">Scheduled Date</label>
            <input
              type="datetime-local"
              className="form-control"
              required
              value={formData.scheduledDate}
              onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
            />
          </div>
          <div className="form-actions">
            <button type="button" className="btn btn--outline" onClick={() => setShowModal(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn--primary">
              <i className="fas fa-save"></i> Schedule Task
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

// Performance Reporting Component
const PerformanceReporting = ({ data, onUpdateData }) => {
  const [reports, setReports] = useState(data.reports);
  const [selectedReportType, setSelectedReportType] = useState('');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [alert, setAlert] = useState(null);
  const [loading, setLoading] = useState(false);

  const reportTypes = [
    'Inventory Turnover',
    'Space Utilization',
    'Shipment Performance',
    'Maintenance Summary',
    'Operational Efficiency'
  ];

  const handleGenerateReport = () => {
    if (!selectedReportType) {
      setAlert({ type: 'error', message: 'Please select a report type.' });
      return;
    }

    setLoading(true);
    
    setTimeout(() => {
      const newReport = {
        reportId: Math.max(...reports.map(r => r.reportId)) + 1,
        reportType: selectedReportType,
        generatedOn: new Date().toISOString(),
        details: getReportDetails(selectedReportType)
      };

      const updatedReports = [...reports, newReport];
      setReports(updatedReports);
      onUpdateData({ ...data, reports: updatedReports });
      setAlert({ type: 'success', message: 'Report generated successfully!' });
      setLoading(false);
    }, 2000);
  };

  const getReportDetails = (reportType) => {
    switch (reportType) {
      case 'Inventory Turnover':
        return 'Current inventory turnover analysis showing improved efficiency across all categories';
      case 'Space Utilization':
        return `Overall space utilization at ${data.dashboardMetrics.spaceUtilization}% with optimization recommendations`;
      case 'Shipment Performance':
        return 'Shipment tracking performance metrics with delivery time analysis and trends';
      case 'Maintenance Summary':
        return 'Comprehensive maintenance schedule performance and equipment uptime statistics';
      case 'Operational Efficiency':
        return 'Complete operational metrics including productivity gains and cost analysis';
      default:
        return 'Generated report with comprehensive analytics and insights';
    }
  };

  const getReportIcon = (reportType) => {
    switch (reportType) {
      case 'Inventory Turnover': return 'fa-boxes';
      case 'Space Utilization': return 'fa-warehouse';
      case 'Shipment Performance': return 'fa-truck';
      case 'Maintenance Summary': return 'fa-wrench';
      default: return 'fa-chart-bar';
    }
  };

  return (
    <div>
      <div className="header">
        <div className="header__title">
          <h1>Performance Reporting</h1>
          <p>Generate comprehensive reports and analytics to monitor warehouse performance and operations.</p>
        </div>
      </div>

      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          onClose={() => setAlert(null)} 
        />
      )}

      <div className="report-generation">
        <h3>Generate New Report</h3>
        <div className="report-filters">
          <div className="form-group">
            <label className="form-label">Report Type</label>
            <select
              className="form-control"
              value={selectedReportType}
              onChange={(e) => setSelectedReportType(e.target.value)}
            >
              <option value="">Select Report Type</option>
              {reportTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Start Date</label>
            <input
              type="date"
              className="form-control"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label className="form-label">End Date</label>
            <input
              type="date"
              className="form-control"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
            />
          </div>
        </div>
        <button 
          className="btn btn--primary" 
          onClick={handleGenerateReport}
          disabled={loading}
        >
          {loading ? (
            <>
              <div className="loading-spinner" style={{width: '16px', height: '16px', marginRight: '8px'}}></div>
              Generating...
            </>
          ) : (
            <>
              <i className="fas fa-chart-line"></i> Generate Report
            </>
          )}
        </button>
      </div>

      <div className="content-section">
        <div className="content-section__header">
          <h3 className="content-section__title">Generated Reports</h3>
        </div>
        <div className="content-section__body">
          {reports.length > 0 ? (
            <div className="dashboard-grid">
              {reports.map(report => (
                <div key={report.reportId} className="metric-card">
                  <div className="metric-card__header">
                    <span className="metric-card__title">{report.reportType}</span>
                    <div className="metric-card__icon metric-card__icon--primary">
                      <i className={`fas ${getReportIcon(report.reportType)}`}></i>
                    </div>
                  </div>
                  <p style={{fontSize: '14px', lineHeight: '1.5', margin: '12px 0'}}>
                    {report.details}
                  </p>
                  <div style={{fontSize: '12px', color: 'var(--color-text-secondary)'}}>
                    Generated: {formatDate(report.generatedOn)}
                  </div>
                  <div className="form-actions" style={{marginTop: '16px', paddingTop: '16px'}}>
                    <button className="btn btn--sm btn--outline">
                      <i className="fas fa-eye"></i> View
                    </button>
                    <button className="btn btn--sm btn--primary">
                      <i className="fas fa-download"></i> Export
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <i className="fas fa-chart-bar"></i>
              <h3>No reports generated</h3>
              <p>Generate your first report to view analytics and insights.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [data, setData] = useState(initialData);
  const [sidebarVisible, setSidebarVisible] = useState(true);

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-tachometer-alt' },
    { id: 'inventory', label: 'Inventory Management', icon: 'fa-boxes' },
    { id: 'space', label: 'Space Optimization', icon: 'fa-warehouse' },
    { id: 'shipments', label: 'Shipment Handling', icon: 'fa-truck' },
    { id: 'maintenance', label: 'Maintenance Scheduling', icon: 'fa-wrench' },
    { id: 'reports', label: 'Performance Reporting', icon: 'fa-chart-bar' }
  ];

  const handleUpdateData = (newData) => {
    setData(newData);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard data={data} />;
      case 'inventory':
        return <InventoryManagement data={data} onUpdateData={handleUpdateData} />;
      case 'space':
        return <SpaceOptimization data={data} onUpdateData={handleUpdateData} />;
      case 'shipments':
        return <ShipmentHandling data={data} onUpdateData={handleUpdateData} />;
      case 'maintenance':
        return <MaintenanceScheduling data={data} onUpdateData={handleUpdateData} />;
      case 'reports':
        return <PerformanceReporting data={data} onUpdateData={handleUpdateData} />;
      default:
        return <Dashboard data={data} />;
    }
  };

  return (
    <div className="app">
      <aside className={`sidebar ${sidebarVisible ? '' : 'mobile-hidden'}`}>
        <div className="sidebar__logo">
          <div className="metric-card__icon metric-card__icon--primary">
            <i className="fas fa-warehouse"></i>
          </div>
          <h1>LWMS</h1>
        </div>
        <nav>
          <ul className="sidebar__nav">
            {navigationItems.map(item => (
              <li key={item.id} className="sidebar__nav-item">
                <a
                  href="#"
                  className={`sidebar__nav-link ${currentPage === item.id ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage(item.id);
                    if (window.innerWidth <= 768) {
                      setSidebarVisible(false);
                    }
                  }}
                >
                  <i className={`fas ${item.icon}`}></i>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      <main className={`main-content ${sidebarVisible ? '' : 'sidebar-hidden'}`}>
        <button 
          className="mobile-menu-btn"
          onClick={() => setSidebarVisible(!sidebarVisible)}
        >
          <i className="fas fa-bars"></i>
        </button>
        {renderCurrentPage()}
      </main>
    </div>
  );
};

// Render the app
ReactDOM.render(<App />, document.getElementById('root'));